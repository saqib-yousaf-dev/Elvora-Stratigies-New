import { CheckCircle, Shield, ArrowLeft } from "lucide-react";

const LOGO = "/manus-storage/elvora_logo_nobg_2db64aeb.png";

export default function DataSecurityPage() {
  return (
    <div style={{ background: "#ffffff", minHeight: "100vh" }}>
      {/* Simple nav */}
      <nav className="border-b px-6 py-4 flex items-center gap-4" style={{ borderColor: "#e0f2fe" }}>
        <a href="/" className="flex items-center gap-2 text-sm font-semibold hover:opacity-80 transition-opacity" style={{ color: "#0284c7" }}>
          <ArrowLeft size={16} /> Back to Home
        </a>
        <img src={LOGO} alt="Elvora Strategies" className="h-8 w-auto ml-auto" />
      </nav>

      <div className="max-w-4xl mx-auto px-6 lg:px-10 py-20">
        {/* Header */}
        <div className="mb-16">
          <span className="text-xs font-bold tracking-widest uppercase mb-3 block" style={{ color: "#0ea5e9" }}>
            Elvora Strategies
          </span>
          <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-4" style={{ fontFamily: "'Playfair Display', serif" }}>
            Data & Security
          </h1>
          <p className="text-gray-500 text-lg">
            We take data protection seriously. Here is exactly what we collect, how we protect it, and what rights you have.
          </p>
          <p className="text-xs text-gray-400 mt-3">Last updated: August 2026</p>
        </div>

        {/* What We Collect */}
        <section className="mb-14">
          <h2 className="text-2xl font-bold text-gray-900 mb-6 pb-3 border-b" style={{ fontFamily: "'Playfair Display', serif", borderColor: "#e0f2fe" }}>
            What We Collect
          </h2>
          <p className="text-gray-600 mb-4">
            When a visitor interacts with Pulse on your website, we collect the information needed to deliver a qualified lead to your business. The exact data captured is configured per client and may vary depending on your industry, workflow, and requirements. This typically includes — but is not limited to:
          </p>
          <ul className="flex flex-col gap-3 mb-6">
            {[
              "Visitor contact details — such as name, email address, and phone number",
              "Enquiry information — a structured summary of the visitor's needs, intent, and any qualifying details",
              "Conversation transcript — the full record of the interaction between the visitor and Pulse",
              "Contextual data — such as date, time, browser language, and display preferences",
              "Any additional fields configured for your specific business — for example, case type, property details, appointment preferences, or urgency level",
            ].map(item => (
              <li key={item} className="flex items-start gap-3 text-gray-700">
                <CheckCircle size={18} className="flex-shrink-0 mt-0.5" style={{ color: "#0ea5e9" }} />
                {item}
              </li>
            ))}
          </ul>
          <div className="p-4 border-l-4" style={{ borderColor: "#0ea5e9", background: "#f0f9ff" }}>
            <p className="text-sm text-gray-700 font-semibold">We never store payment card details or visitor passwords.</p>
          </div>
        </section>

        {/* How It's Protected */}
        <section className="mb-14">
          <h2 className="text-2xl font-bold text-gray-900 mb-6 pb-3 border-b" style={{ fontFamily: "'Playfair Display', serif", borderColor: "#e0f2fe" }}>
            How It's Protected
          </h2>
          <ul className="flex flex-col gap-4">
            {[
              { title: "Encrypted in transit", desc: "HTTPS/SSL between visitors, our server, and lead emails." },
              { title: "Encrypted at rest", desc: "Sensitive lead fields (name, email, phone) are encrypted in our database." },
              { title: "Restricted database access", desc: "A dedicated, limited-permission database user — not full admin." },
              { title: "Firewall-protected server", desc: "Only essential ports are open; the database is not reachable from outside." },
              { title: "Hashed login credentials", desc: "Passwords are scrambled, never stored as readable text." },
              { title: "Daily automated backups", desc: "14-day rolling retention so data is never permanently lost." },
              { title: "24/7 automated monitoring", desc: "Alerts are triggered immediately if anything goes down." },
            ].map(item => (
              <li key={item.title} className="flex items-start gap-4 p-4 border" style={{ borderColor: "#e0f2fe" }}>
                <Shield size={20} className="flex-shrink-0 mt-0.5" style={{ color: "#0ea5e9" }} />
                <div>
                  <p className="font-semibold text-gray-900">{item.title}</p>
                  <p className="text-gray-600 text-sm mt-1">{item.desc}</p>
                </div>
              </li>
            ))}
          </ul>
        </section>

        {/* Infrastructure */}
        <section className="mb-14">
          <h2 className="text-2xl font-bold text-gray-900 mb-6 pb-3 border-b" style={{ fontFamily: "'Playfair Display', serif", borderColor: "#e0f2fe" }}>
            Infrastructure
          </h2>
          <ul className="flex flex-col gap-3">
            {[
              "Hosted on our own private servers — not a shared third-party chatbot platform.",
              "AI powered by Claude, from Anthropic.",
              "Data stored in PostgreSQL, an industry-standard relational database.",
              "Load-tested to handle multiple simultaneous conversations reliably.",
            ].map(item => (
              <li key={item} className="flex items-start gap-3 text-gray-700">
                <CheckCircle size={18} className="flex-shrink-0 mt-0.5" style={{ color: "#0ea5e9" }} />
                {item}
              </li>
            ))}
          </ul>
        </section>

        {/* Your Data, Your Control */}
        <section className="mb-14">
          <h2 className="text-2xl font-bold text-gray-900 mb-6 pb-3 border-b" style={{ fontFamily: "'Playfair Display', serif", borderColor: "#e0f2fe" }}>
            Your Data, Your Control
          </h2>
          <ul className="flex flex-col gap-3 mb-8">
            {[
              "Never shared between clients — each business's data is fully separated.",
              "Deletion available on request at any time.",
              "Data is never sold or used for third-party marketing.",
            ].map(item => (
              <li key={item} className="flex items-start gap-3 text-gray-700">
                <CheckCircle size={18} className="flex-shrink-0 mt-0.5" style={{ color: "#F5A623" }} />
                {item}
              </li>
            ))}
          </ul>
        </section>

        {/* Insurance */}
        <section className="mb-14">
          <h2 className="text-2xl font-bold text-gray-900 mb-4 pb-3 border-b" style={{ fontFamily: "'Playfair Display', serif", borderColor: "#e0f2fe" }}>
            Insurance
          </h2>
          <p className="text-gray-700">
            Elvora Strategies is backed by <strong>Professional Indemnity Insurance</strong>, <strong>Cyber & Data Insurance</strong>, and <strong>Legal Protection Insurance</strong>.
          </p>
        </section>



        {/* Contact */}
        <section className="p-8 border-t" style={{ borderColor: "#e0f2fe" }}>
          <h2 className="text-xl font-bold text-gray-900 mb-3" style={{ fontFamily: "'Playfair Display', serif" }}>
            Questions or Data Requests?
          </h2>
          <p className="text-gray-600 mb-2">
            To request deletion of your data, access your data, or ask any data-related question, contact us at:
          </p>
          <a href="mailto:info@elvorastrategies.com" className="font-semibold hover:underline" style={{ color: "#0284c7" }}>
            info@elvorastrategies.com
          </a>
        </section>
      </div>
    </div>
  );
}
