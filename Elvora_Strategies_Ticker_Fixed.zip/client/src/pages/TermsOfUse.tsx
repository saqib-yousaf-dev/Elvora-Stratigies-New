import { ArrowLeft } from "lucide-react";

const LOGO = "/manus-storage/elvora_logo_nobg_2db64aeb.png";

export default function TermsOfUse() {
  return (
    <div style={{ background: "#ffffff", minHeight: "100vh" }}>
      <nav className="border-b px-6 py-4 flex items-center gap-4" style={{ borderColor: "#e0f2fe" }}>
        <a href="/" className="flex items-center gap-2 text-sm font-semibold hover:opacity-80 transition-opacity" style={{ color: "#0284c7" }}>
          <ArrowLeft size={16} /> Back to Home
        </a>
        <img src={LOGO} alt="Elvora Strategies" className="h-8 w-auto ml-auto" />
      </nav>

      <div className="max-w-4xl mx-auto px-6 lg:px-10 py-20">
        <div className="mb-12">
          <span className="text-xs font-bold tracking-widest uppercase mb-3 block" style={{ color: "#0ea5e9" }}>Legal</span>
          <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-4" style={{ fontFamily: "'Playfair Display', serif" }}>
            Terms of Use
          </h1>
          <p className="text-gray-500">Last updated: August 2026</p>
        </div>

        <div className="prose max-w-none text-gray-700 space-y-10">
          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4 pb-2 border-b" style={{ fontFamily: "'Playfair Display', serif", borderColor: "#e0f2fe" }}>1. About These Terms</h2>
            <p>These Terms of Use govern your use of the Elvora Strategies website (elvorastrategies.com) and the Pulse AI receptionist service. By using our website or services, you agree to these terms. If you do not agree, please do not use our services.</p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4 pb-2 border-b" style={{ fontFamily: "'Playfair Display', serif", borderColor: "#e0f2fe" }}>2. Our Services</h2>
            <p>Elvora Strategies provides bespoke AI chatbot receptionist services under the product name Pulse. Each deployment is custom-built and trained specifically for the client's business. Services are provided under a separate written agreement between Elvora Strategies and the client.</p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4 pb-2 border-b" style={{ fontFamily: "'Playfair Display', serif", borderColor: "#e0f2fe" }}>3. Use of This Website</h2>
            <p className="mb-3">You agree not to:</p>
            <ul className="list-disc pl-6 space-y-2">
              <li>Use this website for any unlawful purpose</li>
              <li>Attempt to gain unauthorised access to any part of our systems</li>
              <li>Transmit any harmful, offensive, or disruptive content via our chatbot or contact channels</li>
              <li>Reproduce or redistribute any content from this website without permission</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4 pb-2 border-b" style={{ fontFamily: "'Playfair Display', serif", borderColor: "#e0f2fe" }}>4. Subscriptions & Payments</h2>
            <p>Paid plans are billed monthly via Stripe. All prices are in GBP and exclusive of VAT where applicable. Conversations beyond your monthly plan allowance are billed at £0.50 per conversation. Elvora Strategies reserves the right to update pricing with reasonable notice. Refunds are handled on a case-by-case basis — contact us at <a href="mailto:info@elvorastrategies.com" className="underline" style={{ color: "#0284c7" }}>info@elvorastrategies.com</a>.</p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4 pb-2 border-b" style={{ fontFamily: "'Playfair Display', serif", borderColor: "#e0f2fe" }}>5. Intellectual Property</h2>
            <p>All content on this website — including text, design, graphics, and the Elvora Strategies and Pulse brand names — is the intellectual property of Elvora Strategies. You may not copy, reproduce, or use any of it without our written permission.</p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4 pb-2 border-b" style={{ fontFamily: "'Playfair Display', serif", borderColor: "#e0f2fe" }}>6. Limitation of Liability</h2>
            <p>Elvora Strategies provides its services in good faith. We are not liable for any indirect, incidental, or consequential loss arising from use of our services or website. Our total liability in any circumstance shall not exceed the amount paid by the client in the preceding month.</p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4 pb-2 border-b" style={{ fontFamily: "'Playfair Display', serif", borderColor: "#e0f2fe" }}>7. Termination</h2>
            <p>Either party may terminate the service with 30 days' written notice. Elvora Strategies reserves the right to suspend or terminate access immediately in cases of misuse, non-payment, or breach of these terms.</p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4 pb-2 border-b" style={{ fontFamily: "'Playfair Display', serif", borderColor: "#e0f2fe" }}>8. Governing Law</h2>
            <p>These terms are governed by the laws of England and Wales. Any disputes shall be subject to the exclusive jurisdiction of the courts of England and Wales.</p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4 pb-2 border-b" style={{ fontFamily: "'Playfair Display', serif", borderColor: "#e0f2fe" }}>9. Contact</h2>
            <p>For any questions about these terms: <a href="mailto:info@elvorastrategies.com" className="underline" style={{ color: "#0284c7" }}>info@elvorastrategies.com</a></p>
          </section>
        </div>
      </div>
    </div>
  );
}

