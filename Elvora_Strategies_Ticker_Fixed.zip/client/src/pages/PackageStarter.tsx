import { Link } from "wouter";
import { CheckCircle, ArrowLeft, MessageSquare } from "lucide-react";

const LOGO = "/manus-storage/elvora_logo_nobg_2db64aeb.png";

function openChatbot() {
  const el = document.getElementById("pulse-launcher");
  if (el) el.click();
}

const FEATURES = [
  { title: "One Custom AI Receptionist", desc: "Your Pulse assistant is built and trained exclusively on your business — your tone, your services, your industry. No templates, no generic scripts." },
  { title: "Lead Capture to Your Inbox, 24/7", desc: "Every qualified enquiry is delivered straight to your inbox the moment the conversation ends — formatted, structured, and ready to act on." },
  { title: "250 Conversations per Month", desc: "Covers up to 250 visitor interactions per month. Any conversations beyond your allowance are billed at £0.50 each — your assistant never stops working." },
  { title: "Standard Setup & Onboarding", desc: "We handle the full build and deployment. From your 30-minute discovery call to going live, we manage everything — typically within 14 days." },
  { title: "Email Support", desc: "Direct email support from the Elvora Strategies team. We're here to help with any questions, adjustments, or updates after launch." },
];

const IDEAL_FOR = [
  "Solo practitioners (coaches, consultants, therapists)",
  "Small professional offices with lower enquiry volumes",
  "Businesses new to AI automation looking to start lean",
  "Any practice that wants 24/7 coverage without a large commitment",
];

export default function PackageStarter() {
  return (
    <div className="min-h-screen" style={{ background: "#f0f9ff" }}>
      {/* Navbar */}
      <nav className="sticky top-0 z-50 bg-white border-b px-6 lg:px-10 py-4 flex items-center justify-between" style={{ borderColor: "#e0f2fe" }}>
        <Link href="/">
          <span className="flex items-center gap-3 cursor-pointer">
            <img src={LOGO} alt="Elvora Strategies" className="h-9 w-auto" />
            <span className="font-black text-xl text-gray-900 uppercase tracking-widest" style={{ fontFamily: "'DM Sans', sans-serif" }}>
              Elvora <span style={{ color: "#F5A623" }}>Strategies</span>
            </span>
          </span>
        </Link>
        <Link href="/#pricing">
          <span className="flex items-center gap-2 text-sm font-semibold text-gray-600 hover:text-gray-900 cursor-pointer transition-colors">
            <ArrowLeft size={16} /> All Plans
          </span>
        </Link>
      </nav>

      {/* Hero */}
      <section className="py-20 px-6 lg:px-10" style={{ background: "linear-gradient(135deg, #0ea5e9 0%, #38bdf8 50%, #7dd3fc 100%)" }}>
        <div className="max-w-4xl mx-auto text-center">
          <span className="text-xs font-bold tracking-widest uppercase mb-4 block text-white/70">Starter Plan</span>
          <h1 className="text-5xl lg:text-6xl font-bold text-white mb-4" style={{ fontFamily: "'Playfair Display', serif" }}>
            £99 <span className="text-3xl font-normal text-white/80">/ month</span>
          </h1>
          <p className="text-white/80 text-lg mb-2">or <strong className="text-white">£1,069 / year</strong> — save 10%</p>
          <p className="text-white/90 text-xl mt-6 max-w-2xl mx-auto">
            Perfect for solo practitioners and small offices ready to capture every enquiry, 24 hours a day.
          </p>
          <button onClick={openChatbot} className="mt-10 inline-flex items-center justify-center gap-2 font-bold text-sm px-8 py-4 transition-all duration-200 active:scale-95" style={{ background: "#F5A623", color: "#1a1a1a" }}>
            <MessageSquare size={18} /> Book a Demo
          </button>
        </div>
      </section>

      {/* What's Included */}
      <section className="py-20 px-6 lg:px-10">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold text-gray-900 mb-12 text-center" style={{ fontFamily: "'Playfair Display', serif" }}>
            Everything in the <span style={{ color: "#0ea5e9" }}>Starter Plan</span>
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {FEATURES.map((f) => (
              <div key={f.title} className="bg-white p-8 border" style={{ borderTop: "3px solid #0ea5e9", borderColor: "#e0f2fe" }}>
                <div className="flex items-start gap-4">
                  <CheckCircle size={22} className="flex-shrink-0 mt-0.5" style={{ color: "#0ea5e9" }} />
                  <div>
                    <h3 className="font-bold text-gray-900 mb-2">{f.title}</h3>
                    <p className="text-gray-500 text-sm leading-relaxed">{f.desc}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Ideal For */}
      <section className="py-16 px-6 lg:px-10 bg-white">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-2xl font-bold text-gray-900 mb-8" style={{ fontFamily: "'Playfair Display', serif" }}>
            Ideal For
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {IDEAL_FOR.map((item) => (
              <div key={item} className="flex items-start gap-3 p-5 border" style={{ borderLeft: "3px solid #F5A623", borderColor: "#e0f2fe" }}>
                <CheckCircle size={16} className="flex-shrink-0 mt-0.5" style={{ color: "#F5A623" }} />
                <span className="text-gray-700 text-sm">{item}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Upgrade note */}
      <section className="py-16 px-6 lg:px-10" style={{ background: "#f0f9ff" }}>
        <div className="max-w-4xl mx-auto text-center">
          <p className="text-gray-500 mb-2 text-sm">Need more conversations or advanced features?</p>
          <Link href="/packages/professional">
            <span className="font-bold text-sm cursor-pointer hover:underline" style={{ color: "#0ea5e9" }}>
              View the Professional Plan →
            </span>
          </Link>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 px-6 lg:px-10" style={{ background: "#0ea5e9" }}>
        <div className="max-w-2xl mx-auto text-center">
          <h2 className="text-3xl font-bold text-white mb-4" style={{ fontFamily: "'Playfair Display', serif" }}>
            Ready to get started?
          </h2>
          <p className="text-white/80 mb-8">Your AI receptionist can be live in under 2 weeks.</p>
          <button
            onClick={openChatbot}
            className="inline-flex items-center justify-center gap-2 font-bold text-sm px-8 py-4"
            style={{ background: "#F5A623", color: "#1a1a1a" }}
          >
            <MessageSquare size={18} /> Book a Demo
          </button>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-6 text-center border-t" style={{ background: "#ffffff", borderColor: "#e0f2fe" }}>
        <p className="text-gray-400 text-sm">© {new Date().getFullYear()} Elvora Strategies. All rights reserved.</p>
      </footer>
    </div>
  );
}
