import { ArrowLeft } from "lucide-react";

const LOGO = "/manus-storage/elvora_logo_nobg_2db64aeb.png";

export default function PrivacyPolicy() {
  return (
    <div style={{ background: "#ffffff", minHeight: "100vh" }}>
      <nav className="border-b px-6 py-4 flex items-center gap-4" style={{ borderColor: "#e0f2fe" }}>
        <a href="/" className="flex items-center gap-2 text-sm font-semibold hover:opacity-80 transition-opacity" style={{ color: "#0284c7" }}>
          <ArrowLeft size={16} /> Back to Home
        </a>
        <img src={LOGO} alt="Elvora Strategies" className="h-8 w-auto ml-auto" />
      </nav>

      <div className="max-w-4xl mx-auto px-6 lg:px-10 py-20">
        <div className="mb-12">
          <span className="text-xs font-bold tracking-widest uppercase mb-3 block" style={{ color: "#0ea5e9" }}>Legal</span>
          <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-4" style={{ fontFamily: "'Playfair Display', serif" }}>
            Privacy Policy
          </h1>
          <p className="text-gray-500">Last updated: August 2026</p>
        </div>

        <div className="prose max-w-none text-gray-700 space-y-10">
          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4 pb-2 border-b" style={{ fontFamily: "'Playfair Display', serif", borderColor: "#e0f2fe" }}>1. Who We Are</h2>
            <p>ELVORASTRATEGIES LTD is an AI automation agency based in Manchester, UK. We build bespoke AI chatbot receptionists for businesses. Our registered office is First Floor, Swan Buildings, 20 Swan Street, Manchester, M4 5JW. You can contact us at <a href="mailto:info@elvorastrategies.com" className="underline" style={{ color: "#0284c7" }}>info@elvorastrategies.com</a> or <a href="tel:+441615150022" className="underline" style={{ color: "#0284c7" }}>01615 150022</a>.</p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4 pb-2 border-b" style={{ fontFamily: "'Playfair Display', serif", borderColor: "#e0f2fe" }}>2. What Data We Collect</h2>
            <p className="mb-3">We collect data in two contexts:</p>
            <p className="font-semibold mb-2">a) Website visitors (elvorastrategies.com)</p>
            <p className="mb-4">If you contact us via our chatbot, email, or WhatsApp, we may collect your name, email address, phone number, and the content of your enquiry.</p>
            <p className="font-semibold mb-2">b) End users of our clients' Pulse AI receptionists</p>
            <p>When a visitor interacts with a Pulse AI receptionist deployed on a client's website, we collect information on behalf of that client. This may include — but is not limited to — contact details, enquiry summaries, conversation transcripts, and any additional fields configured for that client's specific business needs. The exact data collected varies by client and industry.</p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4 pb-2 border-b" style={{ fontFamily: "'Playfair Display', serif", borderColor: "#e0f2fe" }}>3. How We Use Your Data</h2>
            <ul className="list-disc pl-6 space-y-2">
              <li>To respond to your enquiry or provide the services you have requested</li>
              <li>To deliver qualified leads to our clients on whose websites Pulse is deployed</li>
              <li>To improve the performance and accuracy of our AI systems</li>
              <li>To comply with legal obligations</li>
            </ul>
            <p className="mt-3">We do not sell your data. We do not use your data for third-party advertising or marketing.</p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4 pb-2 border-b" style={{ fontFamily: "'Playfair Display', serif", borderColor: "#e0f2fe" }}>4. Legal Basis for Processing</h2>
            <p>We process personal data under the following lawful bases (UK GDPR):</p>
            <ul className="list-disc pl-6 space-y-2 mt-3">
              <li><strong>Legitimate interests</strong> — to deliver lead capture services to our clients</li>
              <li><strong>Contractual necessity</strong> — to fulfil our service agreements with clients</li>
              <li><strong>Consent</strong> — where visitors have been informed that a Pulse AI assistant is active on the site</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4 pb-2 border-b" style={{ fontFamily: "'Playfair Display', serif", borderColor: "#e0f2fe" }}>5. Data Retention</h2>
            <p>Lead data is retained for as long as required to fulfil the service or as agreed with the client. Daily automated backups are kept for 14 days. You may request deletion of your data at any time by contacting us.</p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4 pb-2 border-b" style={{ fontFamily: "'Playfair Display', serif", borderColor: "#e0f2fe" }}>6. Your Rights</h2>
            <p className="mb-3">Under UK GDPR, you have the right to:</p>
            <ul className="list-disc pl-6 space-y-2">
              <li>Access the personal data we hold about you</li>
              <li>Request correction of inaccurate data</li>
              <li>Request erasure of your data</li>
              <li>Object to or restrict processing</li>
              <li>Lodge a complaint with the ICO (ico.org.uk)</li>
            </ul>
            <p className="mt-3">To exercise any of these rights, contact us at <a href="mailto:info@elvorastrategies.com" className="underline" style={{ color: "#0284c7" }}>info@elvorastrategies.com</a>.</p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4 pb-2 border-b" style={{ fontFamily: "'Playfair Display', serif", borderColor: "#e0f2fe" }}>7. Third Parties</h2>
            <p>Our AI is powered by Claude (Anthropic). Data is processed on our own private servers. We do not share personal data with any third party for marketing purposes. We may share data with law enforcement or regulatory bodies if required by law.</p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4 pb-2 border-b" style={{ fontFamily: "'Playfair Display', serif", borderColor: "#e0f2fe" }}>8. Security</h2>
            <p>We use industry-standard security measures including HTTPS/SSL encryption in transit, encryption at rest for sensitive fields, firewall-protected servers, and 24/7 automated monitoring. Full details are available on our <a href="/data-security" className="underline" style={{ color: "#0284c7" }}>Data & Security page</a>.</p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4 pb-2 border-b" style={{ fontFamily: "'Playfair Display', serif", borderColor: "#e0f2fe" }}>9. Contact</h2>
            <p>For any privacy-related questions or requests: <a href="mailto:info@elvorastrategies.com" className="underline" style={{ color: "#0284c7" }}>info@elvorastrategies.com</a></p>
          </section>
        </div>
      </div>
    </div>
  );
}
