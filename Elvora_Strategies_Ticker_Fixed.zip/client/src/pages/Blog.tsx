/*
 * Elvora Strategies — Blog / Resources Page
 * Sky Blue / White / Light Mango Amber — no black backgrounds
 * SEO-targeted articles for AI chatbot keywords
 */
import { Link } from "wouter";
import { ArrowRight, Calendar, Clock } from "lucide-react";

const LOGO_TRANSPARENT = "/manus-storage/elvora_logo_nobg_2db64aeb.png";

export const BLOG_POSTS = [
  {
    slug: "ai-chatbot-for-law-firms-uk",
    title: "Why Every UK Law Firm Needs an AI Chatbot Receptionist in 2026",
    metaTitle: "AI Chatbot for Law Firms UK | Elvora Strategies",
    metaDesc: "Discover how AI chatbot receptionists are helping UK law firms capture more leads, respond faster, and never miss a client enquiry — 24 hours a day.",
    category: "Law Firms",
    date: "July 2026",
    readTime: "5 min read",
    excerpt: "Law firms across the UK are losing potential clients every day — not because of their service, but because no one answers the phone at 9pm on a Tuesday. An AI chatbot receptionist changes that.",
    content: `
## The Problem Every Law Firm Recognises

A prospective client searches "family solicitor Manchester" at 10pm. They find your website. They read your services page. They want to get in touch — but your office is closed, your contact form feels impersonal, and they don't want to leave a voicemail.

So they click back and try the next firm on Google.

This happens hundreds of times a year at law firms across the UK. The enquiry was there. The intent was there. The only thing missing was someone — or something — to respond.

## What an AI Chatbot Receptionist Does Differently

An AI chatbot receptionist built by Elvora Strategies isn't a generic pop-up asking "Can I help you?" It's a bespoke AI assistant trained specifically on your firm — your practice areas, your tone, your intake questions.

When a visitor lands on your site at any hour, Pulse:

- **Greets them** in your firm's voice — professional, reassuring, and specific to your practice areas
- **Qualifies the enquiry** — asking the right questions to understand whether this is a family matter, a commercial dispute, a conveyancing enquiry, or something else entirely
- **Captures their details** — name, email, phone number, and a summary of their matter
- **Delivers the lead** directly to your inbox or CRM, ready for a follow-up call the next morning

No generic scripts. No frustrating FAQ loops. A genuine, consultative conversation that makes the prospect feel heard — and keeps them on your site.

## The Numbers That Matter for Law Firms

Law firms that have deployed AI chatbot receptionists typically see:

- **34+ qualified leads per month** captured outside office hours
- **Response time under 2 minutes** — versus the industry average of 6+ hours for email enquiries
- **Zero missed weekend enquiries** — a consistent pain point for smaller practices

For a firm that converts even 10% of those additional leads, the return on investment is immediate.

## Why "AI Chatbot for Law Firms UK" Is a Different Brief

A law firm chatbot isn't the same as a retail chatbot. It needs to understand legal terminology without giving legal advice. It needs to be empathetic — many enquiries involve sensitive personal circumstances. And it needs to comply with SRA guidelines around client communication and data handling.

At Elvora Strategies, every AI receptionist we build for a law firm is trained with these constraints built in. The bot knows what it can and cannot say. It captures what you need. And it hands off to your team at exactly the right moment.

## Getting Started

If your firm receives more than 20 enquiries per month and you don't have a 24/7 response solution in place, you are leaving revenue on the table. Book a demo with Elvora Strategies and see Pulse in action — a live AI receptionist trained on a real law firm brief, ready to show you exactly what yours would look like.
    `,
  },
  {
    slug: "ai-receptionist-small-business-manchester",
    title: "AI Receptionist for Small Business: How Manchester Firms Are Winning More Clients",
    metaTitle: "AI Receptionist for Small Business Manchester | Elvora Strategies",
    metaDesc: "Small businesses in Manchester are using AI receptionists to compete with larger firms — capturing leads 24/7 without hiring extra staff. Here's how it works.",
    category: "Small Business",
    date: "July 2026",
    readTime: "4 min read",
    excerpt: "You don't need a team of receptionists to respond like a large firm. Manchester's fastest-growing small businesses are using AI to punch above their weight — and it's working.",
    content: `
## The Small Business Receptionist Problem

Running a small business in Manchester means wearing a lot of hats. You're the owner, the service provider, the salesperson, and often — the receptionist. Every time your phone rings while you're with a client, you're choosing between the person in front of you and the potential client trying to reach you.

That's not a sustainable way to grow.

## How an AI Receptionist Levels the Playing Field

Large firms have dedicated reception teams, 24/7 call centres, and CRM systems that capture every enquiry automatically. Small businesses in Manchester now have access to exactly the same capability — through an AI receptionist built specifically for their business.

Elvora Strategies builds AI receptionists that:

- **Answer instantly** — no hold music, no voicemail, no missed opportunity
- **Sound like your business** — trained on your services, your tone, and your specific intake process
- **Qualify prospects** — so when you do pick up the phone, you're speaking to someone who already wants what you offer
- **Work 24/7** — including evenings, weekends, and bank holidays when your competitors' phones go unanswered

## Real Results from Northwest England Businesses

Businesses across the Northwest that have deployed Elvora's AI receptionists have reported:

- Appointment bookings up **40% within 6 weeks** of going live
- Weekend enquiries — previously lost entirely — now captured and followed up on Monday morning
- Prospects arriving on calls **already qualified**, reducing time wasted on unsuitable enquiries

## Who Benefits Most?

The AI receptionist for small business model works particularly well for:

- **Estate agents** handling property enquiries outside office hours
- **Insurance brokers** whose clients often research and enquire in the evenings
- **Accountants** who receive a surge of enquiries at tax season and need to capture every one
- **Financial advisors** whose clients value discretion and immediate response
- **Care homes** handling sensitive family enquiries that need a warm, professional first response

## The Manchester Advantage

Manchester's business community is competitive. The firms that respond fastest win the most clients. An AI receptionist doesn't just help you respond faster — it makes you the most responsive business in your category, every single day.

Book a demo with Elvora Strategies and see what a bespoke AI receptionist would look like for your Manchester business.
    `,
  },
  {
    slug: "lead-capture-chatbot-northwest-england",
    title: "Lead Capture Chatbot for Northwest England Businesses: The Complete Guide",
    metaTitle: "Lead Capture Chatbot Northwest England | Elvora Strategies",
    metaDesc: "A complete guide to lead capture chatbots for businesses in Northwest England — what they do, how they work, and why they outperform contact forms and phone lines.",
    category: "Lead Generation",
    date: "August 2026",
    readTime: "6 min read",
    excerpt: "Contact forms convert at 1–3%. Phone lines go unanswered. A lead capture chatbot changes the equation entirely — here's everything Northwest England businesses need to know.",
    content: `
## Why Traditional Lead Capture Is Broken

Most business websites have the same lead capture setup: a contact form, a phone number, and maybe an email address. The problem is that none of these work particularly well.

- **Contact forms** convert at 1–3% and take hours to respond to
- **Phone lines** go unanswered outside business hours — which is when many prospects do their research
- **Email** feels slow and impersonal to a prospect who wants an answer now

For businesses in Northwest England competing for clients in a busy market, this is a significant problem. The enquiry arrives. Nobody responds quickly enough. The prospect moves on.

## What a Lead Capture Chatbot Does Instead

A lead capture chatbot built by Elvora Strategies sits on your website and does something fundamentally different: it has a conversation.

Not a scripted FAQ loop. Not a "press 1 for sales" experience. A genuine, intelligent conversation that:

1. **Greets the visitor** in your business's voice within seconds of them landing on your site
2. **Understands their need** through natural conversation — no forms, no dropdowns
3. **Qualifies the lead** by asking the questions your team would ask
4. **Captures their contact details** — name, email, phone — naturally within the conversation
5. **Delivers a complete lead summary** to your inbox or CRM, ready for follow-up

## The Conversion Difference

Where a contact form converts at 1–3%, a well-designed AI chatbot typically converts at 15–25% of engaged visitors. The reason is simple: people respond to conversation. They feel heard. They get immediate value. And they're far more likely to leave their details when they've already had a positive interaction.

For a business receiving 500 website visitors per month, the difference between a 2% contact form conversion rate and a 20% chatbot conversion rate is the difference between 10 leads and 100 leads — from the same traffic.

## Industries Seeing the Biggest Impact in the Northwest

Across Northwest England, the industries seeing the most significant results from lead capture chatbots are:

**Law Firms** — capturing out-of-hours enquiries that previously went to competitors. AI chatbot for law firms UK is one of the fastest-growing use cases in the legal sector.

**Estate Agents** — handling property enquiries 24/7, qualifying buyers and vendors before the first call.

**Insurance Brokers** — capturing evening and weekend enquiries when clients research their options.

**Accountants** — managing the surge of enquiries around self-assessment deadlines without missing a single one.

**Care Homes** — providing a warm, immediate response to families making sensitive enquiries about care provision.

## How Elvora Strategies Builds Your Chatbot

Every lead capture chatbot we build is bespoke. We don't use templates. We don't deploy generic scripts. We spend time understanding your business, your clients, and your intake process — and we build an AI receptionist that reflects all of that.

The process takes under two weeks from brief to live deployment. And once it's live, it works every hour of every day — capturing leads, qualifying prospects, and delivering them to you ready for follow-up.

If you're a business in Northwest England that receives enquiries and wants to convert more of them, book a demo with Elvora Strategies. See Pulse in action and understand exactly what a bespoke lead capture chatbot would do for your business.
    `,
  },
];

function Navbar() {
  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-xl border-b border-gray-100">
      <div className="max-w-7xl mx-auto px-6 lg:px-10 h-16 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-3">
          <img src={LOGO_TRANSPARENT} alt="Elvora Strategies logo" className="h-9 w-auto" />
          <span className="font-bold text-gray-900" style={{ fontFamily: "'DM Sans', sans-serif" }}>
            Elvora <span style={{ color: "#F5A623" }}>Strategies</span>
          </span>
        </Link>
        <div className="flex items-center gap-6">
          <Link href="/" className="text-sm text-gray-600 hover:text-gray-900 transition-colors">Home</Link>
          <Link href="/blog" className="text-sm font-semibold" style={{ color: "#0ea5e9" }}>Blog</Link>
          <button
            onClick={() => { const el = document.getElementById("pulse-launcher"); if (el) el.click(); }}
            className="text-sm font-bold px-5 py-2 transition-all duration-200 active:scale-95"
            style={{ background: "#F5A623", color: "#1a1a1a" }}
          >
            Book a Demo
          </button>
        </div>
      </div>
    </nav>
  );
}

export default function Blog() {
  return (
    <div className="min-h-screen" style={{ background: "#f8fbff" }}>
      <Navbar />

      {/* Header */}
      <section className="pt-32 pb-16" style={{ background: "linear-gradient(135deg, #0ea5e9 0%, #0284c7 60%, #0369a1 100%)" }}>
        <div className="max-w-7xl mx-auto px-6 lg:px-10">
          <span className="text-xs font-bold tracking-widest uppercase text-white/70 mb-3 block">Resources</span>
          <h1
            className="text-4xl lg:text-5xl font-bold text-white leading-tight mb-4"
            style={{ fontFamily: "'Playfair Display', serif" }}
          >
            Insights on AI Automation{" "}
            <span style={{ color: "#F5A623" }}>for UK Business</span>
          </h1>
          <p className="text-white/80 text-lg max-w-xl">
            Practical guides on AI chatbots, lead capture, and automation — written for law firms, estate agents, accountants, and businesses across the Northwest.
          </p>
        </div>
      </section>

      {/* Articles grid */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-6 lg:px-10">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {BLOG_POSTS.map((post) => (
              <Link key={post.slug} href={`/blog/${post.slug}`}>
                <article
                  className="bg-white border border-gray-100 hover:border-amber-300 hover:shadow-lg transition-all duration-200 cursor-pointer h-full flex flex-col"
                >
                  {/* Category bar */}
                  <div className="h-1" style={{ background: "#F5A623" }} />

                  <div className="p-7 flex flex-col flex-1">
                    <div className="flex items-center gap-3 mb-4">
                      <span
                        className="text-xs font-bold tracking-widest uppercase px-2 py-1"
                        style={{ background: "#e0f2fe", color: "#0369a1" }}
                      >
                        {post.category}
                      </span>
                    </div>

                    <h2
                      className="text-xl font-bold text-gray-900 leading-snug mb-3 flex-1"
                      style={{ fontFamily: "'Playfair Display', serif" }}
                    >
                      {post.title}
                    </h2>

                    <p className="text-gray-500 text-sm leading-relaxed mb-5">
                      {post.excerpt}
                    </p>

                    <div className="flex items-center justify-between mt-auto pt-4 border-t border-gray-100">
                      <div className="flex items-center gap-4 text-xs text-gray-400">
                        <span className="flex items-center gap-1"><Calendar size={12} />{post.date}</span>
                        <span className="flex items-center gap-1"><Clock size={12} />{post.readTime}</span>
                      </div>
                      <span className="flex items-center gap-1 text-xs font-semibold" style={{ color: "#0ea5e9" }}>
                        Read <ArrowRight size={12} />
                      </span>
                    </div>
                  </div>
                </article>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-10 border-t" style={{ background: "#ffffff", borderColor: "#f0e8d8" }}>
        <div className="max-w-7xl mx-auto px-6 lg:px-10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <Link href="/" className="flex items-center gap-3">
            <img src={LOGO_TRANSPARENT} alt="Elvora Strategies" className="h-8 w-auto" />
            <span className="font-black text-sm uppercase text-gray-900" style={{ letterSpacing: "0.12em" }}>Elvora Strategies</span>
          </Link>
          <p className="text-gray-400 text-xs">© {new Date().getFullYear()} Elvora Strategies. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
