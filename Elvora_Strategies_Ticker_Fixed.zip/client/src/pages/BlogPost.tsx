/*
 * Elvora Strategies — Blog Post Detail Page
 * Sky Blue / White / Light Mango Amber — no black backgrounds
 */
import { Link, useParams } from "wouter";
import { ArrowLeft, Calendar, Clock } from "lucide-react";
import { useEffect } from "react";
import { BLOG_POSTS } from "./Blog";

const LOGO_TRANSPARENT = "/manus-storage/elvora_logo_nobg_2db64aeb.png";

function renderMarkdown(content: string): string {
  return content
    .trim()
    .replace(/^## (.+)$/gm, '<h2 class="text-2xl font-bold text-gray-900 mt-10 mb-4" style="font-family: \'Playfair Display\', serif">$1</h2>')
    .replace(/\*\*(.+?)\*\*/g, '<strong class="font-semibold text-gray-900">$1</strong>')
    .replace(/^- (.+)$/gm, '<li class="text-gray-600 leading-relaxed mb-1 ml-4 list-disc">$1</li>')
    .replace(/(<li[\s\S]+?<\/li>)/g, '<ul class="mb-4">$1</ul>')
    .replace(/^(\d+)\. (.+)$/gm, '<li class="text-gray-600 leading-relaxed mb-2 ml-4 list-decimal"><strong class="text-gray-800">$2</strong></li>')
    .replace(/\n\n/g, '</p><p class="text-gray-600 leading-relaxed mb-5">')
    .replace(/^(?!<[hul])(.+)$/gm, (line) => line.startsWith('<') ? line : `<p class="text-gray-600 leading-relaxed mb-5">${line}</p>`);
}

function Navbar() {
  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-xl border-b border-gray-100">
      <div className="max-w-7xl mx-auto px-6 lg:px-10 h-16 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-3">
          <img src={LOGO_TRANSPARENT} alt="Elvora Strategies logo" className="h-9 w-auto" />
          <span className="font-bold text-gray-900" style={{ fontFamily: "'DM Sans', sans-serif" }}>
            Elvora <span style={{ color: "#F5A623" }}>Strategies</span>
          </span>
        </Link>
        <div className="flex items-center gap-6">
          <Link href="/" className="text-sm text-gray-600 hover:text-gray-900 transition-colors">Home</Link>
          <Link href="/blog" className="text-sm text-gray-600 hover:text-gray-900 transition-colors">Blog</Link>
          <button
            onClick={() => { const el = document.getElementById("pulse-launcher"); if (el) el.click(); }}
            className="text-sm font-bold px-5 py-2 transition-all duration-200 active:scale-95"
            style={{ background: "#F5A623", color: "#1a1a1a" }}
          >
            Book a Demo
          </button>
        </div>
      </div>
    </nav>
  );
}

export default function BlogPost() {
  const { slug } = useParams<{ slug: string }>();
  const post = BLOG_POSTS.find((p) => p.slug === slug);

  useEffect(() => {
    if (post) {
      document.title = post.metaTitle;
      const desc = document.querySelector('meta[name="description"]');
      if (desc) desc.setAttribute("content", post.metaDesc);
    }
    window.scrollTo(0, 0);
  }, [post]);

  if (!post) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Article not found</h1>
          <Link href="/blog" className="text-sky-600 hover:underline">← Back to Blog</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen" style={{ background: "#ffffff" }}>
      <Navbar />

      {/* Hero */}
      <section className="pt-28 pb-12" style={{ background: "linear-gradient(135deg, #0ea5e9 0%, #0284c7 60%, #0369a1 100%)" }}>
        <div className="max-w-3xl mx-auto px-6 lg:px-10">
          <Link href="/blog" className="inline-flex items-center gap-2 text-white/70 hover:text-white text-sm mb-8 transition-colors">
            <ArrowLeft size={14} /> Back to Blog
          </Link>
          <span
            className="text-xs font-bold tracking-widest uppercase px-3 py-1 mb-5 inline-block"
            style={{ background: "rgba(255,255,255,0.15)", color: "#fff" }}
          >
            {post.category}
          </span>
          <h1
            className="text-3xl lg:text-4xl font-bold text-white leading-tight mb-5"
            style={{ fontFamily: "'Playfair Display', serif" }}
          >
            {post.title}
          </h1>
          <div className="flex items-center gap-5 text-white/60 text-sm">
            <span className="flex items-center gap-1.5"><Calendar size={13} />{post.date}</span>
            <span className="flex items-center gap-1.5"><Clock size={13} />{post.readTime}</span>
          </div>
        </div>
      </section>

      {/* Article body */}
      <article className="py-16">
        <div className="max-w-3xl mx-auto px-6 lg:px-10">
          <p className="text-xl text-gray-600 leading-relaxed mb-8 font-medium border-l-4 pl-5" style={{ borderColor: "#F5A623" }}>
            {post.excerpt}
          </p>
          <div
            className="prose-content"
            dangerouslySetInnerHTML={{ __html: renderMarkdown(post.content) }}
          />
        </div>
      </article>

      {/* CTA */}
      <section className="py-16" style={{ background: "#f0f9ff" }}>
        <div className="max-w-3xl mx-auto px-6 lg:px-10 text-center">
          <h2
            className="text-3xl font-bold text-gray-900 mb-4"
            style={{ fontFamily: "'Playfair Display', serif" }}
          >
            Ready to See It in Action?
          </h2>
          <p className="text-gray-500 mb-8 max-w-md mx-auto">
            Book a live demo and see exactly what a bespoke AI receptionist would look like for your business.
          </p>
          <button
            onClick={() => { const el = document.getElementById("pulse-launcher"); if (el) el.click(); }}
            className="inline-flex items-center gap-2 font-bold px-8 py-4 transition-all duration-200 active:scale-95"
            style={{ background: "#F5A623", color: "#1a1a1a" }}
          >
            Book a Demo
          </button>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-10 border-t" style={{ background: "#ffffff", borderColor: "#f0e8d8" }}>
        <div className="max-w-7xl mx-auto px-6 lg:px-10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <Link href="/" className="flex items-center gap-3">
            <img src={LOGO_TRANSPARENT} alt="Elvora Strategies" className="h-8 w-auto" />
            <span className="font-black text-sm uppercase text-gray-900" style={{ letterSpacing: "0.12em" }}>Elvora Strategies</span>
          </Link>
          <p className="text-gray-400 text-xs">© {new Date().getFullYear()} Elvora Strategies. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}

