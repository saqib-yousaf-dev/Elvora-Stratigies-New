import { Link } from "wouter";
import { CheckCircle, ArrowLeft, ArrowRight, MessageSquare, Building2, Globe, Zap, Shield } from "lucide-react";

const LOGO = "/manus-storage/elvora_logo_nobg_2db64aeb.png";

function openChatbot() {
  const el = document.getElementById("pulse-launcher");
  if (el) el.click();
}

const FEATURES = [
  { title: "Everything in Growth", desc: "Includes all Growth features: advanced qualification flows, dedicated onboarding support, quarterly strategy reviews, and priority support." },
  { title: "Unlimited Conversations", desc: "No monthly cap. Pulse handles every visitor interaction — however many arrive — without any overage charges." },
  { title: "Multi-Location Deployment", desc: "Deploy Pulse across multiple websites, offices, or brands from a single account. Each location gets its own trained assistant." },
  { title: "Custom Integrations & Workflows", desc: "We build bespoke integrations with your existing systems — your CRM, your practice management software, your internal tools. If it has an API, we can connect it." },
  { title: "Dedicated Account Manager", desc: "A named account manager who knows your business, monitors your performance, and proactively suggests improvements — not a support ticket queue." },
  { title: "SLA-Backed Support", desc: "Formal service level agreement with guaranteed response and resolution times. Enterprise-grade reliability for businesses that can't afford downtime." },
];

const USE_CASES = [
  { icon: Building2, title: "Multi-Site Businesses", desc: "Law firms, estate agencies, or care home groups with multiple locations — each site gets its own trained Pulse assistant." },
  { icon: Globe, title: "Complex Integrations", desc: "Businesses with bespoke CRM systems, practice management software, or internal workflows that need custom API connections." },
  { icon: Zap, title: "High-Volume Practices", desc: "Firms receiving hundreds of enquiries per week who need unlimited capacity and dedicated performance management." },
  { icon: Shield, title: "Regulated Industries", desc: "Highly regulated sectors (financial services, legal, healthcare) requiring bespoke compliance flows and data handling agreements." },
];

export default function PackageCustom() {
  return (
    <div className="min-h-screen" style={{ background: "#f0f9ff" }}>
      {/* Navbar */}
      <nav className="sticky top-0 z-50 bg-white border-b px-6 lg:px-10 py-4 flex items-center justify-between" style={{ borderColor: "#e0f2fe" }}>
        <Link href="/">
          <span className="flex items-center gap-3 cursor-pointer">
            <img src={LOGO} alt="Elvora Strategies" className="h-9 w-auto" />
            <span className="font-black text-xl text-gray-900 uppercase tracking-widest" style={{ fontFamily: "'DM Sans', sans-serif" }}>
              Elvora <span style={{ color: "#F5A623" }}>Strategies</span>
            </span>
          </span>
        </Link>
        <Link href="/#pricing">
          <span className="flex items-center gap-2 text-sm font-semibold text-gray-600 hover:text-gray-900 cursor-pointer transition-colors">
            <ArrowLeft size={16} /> All Plans
          </span>
        </Link>
      </nav>

      {/* Hero */}
      <section className="py-20 px-6 lg:px-10" style={{ background: "linear-gradient(135deg, #1e3a5f 0%, #0369a1 50%, #0284c7 100%)" }}>
        <div className="max-w-4xl mx-auto text-center">
          <span className="text-xs font-bold tracking-widest uppercase mb-4 block text-white/70">Custom Plan</span>
          <h1 className="text-5xl lg:text-6xl font-bold text-white mb-4" style={{ fontFamily: "'Playfair Display', serif" }}>
            Built Around <span style={{ color: "#F5A623" }}>Your Business</span>
          </h1>
          <p className="text-white/80 text-lg mb-2">Pricing tailored to your exact requirements</p>
          <p className="text-white/90 text-xl mt-6 max-w-2xl mx-auto">
            For businesses that need more than a standard plan — unlimited conversations, multi-location deployment, custom integrations, and a dedicated account manager.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center mt-10">
            <button
              onClick={openChatbot}
              className="inline-flex items-center justify-center gap-2 font-bold text-sm px-8 py-4 transition-all duration-200 active:scale-95"
              style={{ background: "#F5A623", color: "#1a1a1a" }}
            >
              <MessageSquare size={18} /> Tell Us What You Need
            </button>
            <a
              href="mailto:info@elvorastrategies.com"
              className="inline-flex items-center justify-center gap-2 font-bold text-sm px-8 py-4 border-2 border-white text-white"
              style={{ background: "transparent" }}
            >
              Email Us Directly <ArrowRight size={18} />
            </a>
          </div>
        </div>
      </section>

      {/* What's Included */}
      <section className="py-20 px-6 lg:px-10">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold text-gray-900 mb-12 text-center" style={{ fontFamily: "'Playfair Display', serif" }}>
            Everything in the <span style={{ color: "#0ea5e9" }}>Custom Plan</span>
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {FEATURES.map((f) => (
              <div key={f.title} className="bg-white p-8 border" style={{ borderTop: "3px solid #F5A623", borderColor: "#e0f2fe" }}>
                <div className="flex items-start gap-4">
                  <CheckCircle size={22} className="flex-shrink-0 mt-0.5" style={{ color: "#F5A623" }} />
                  <div>
                    <h3 className="font-bold text-gray-900 mb-2">{f.title}</h3>
                    <p className="text-gray-500 text-sm leading-relaxed">{f.desc}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Use Cases */}
      <section className="py-16 px-6 lg:px-10 bg-white">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-2xl font-bold text-gray-900 mb-8 text-center" style={{ fontFamily: "'Playfair Display', serif" }}>
            Who This Is For
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {USE_CASES.map((uc) => {
              const Icon = uc.icon;
              return (
                <div key={uc.title} className="p-6 border" style={{ borderLeft: "3px solid #0ea5e9", borderColor: "#e0f2fe" }}>
                  <div className="flex items-start gap-4">
                    <Icon size={22} className="flex-shrink-0 mt-0.5" style={{ color: "#0ea5e9" }} />
                    <div>
                      <h3 className="font-bold text-gray-900 mb-2">{uc.title}</h3>
                      <p className="text-gray-500 text-sm leading-relaxed">{uc.desc}</p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Process */}
      <section className="py-16 px-6 lg:px-10" style={{ background: "#f0f9ff" }}>
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4" style={{ fontFamily: "'Playfair Display', serif" }}>
            How the Custom Process Works
          </h2>
          <p className="text-gray-500 mb-10 max-w-xl mx-auto">We don't quote until we understand your business. Here's what happens after you get in touch:</p>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            {[
              { step: "01", title: "Discovery Call", desc: "We spend 30–60 minutes understanding your business, your systems, and your goals." },
              { step: "02", title: "Bespoke Proposal", desc: "Within 48 hours, you receive a detailed proposal with pricing, scope, and timeline." },
              { step: "03", title: "Build & Go Live", desc: "We handle everything — from integration to training to deployment. You just approve." },
            ].map((s) => (
              <div key={s.step} className="bg-white p-8 border" style={{ borderTop: "3px solid #0ea5e9", borderColor: "#e0f2fe" }}>
                <div className="text-4xl font-black mb-4" style={{ color: "#0ea5e9", fontFamily: "'Playfair Display', serif" }}>{s.step}</div>
                <h3 className="font-bold text-gray-900 mb-2">{s.title}</h3>
                <p className="text-gray-500 text-sm">{s.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 px-6 lg:px-10" style={{ background: "#1e3a5f" }}>
        <div className="max-w-2xl mx-auto text-center">
          <h2 className="text-3xl font-bold text-white mb-4" style={{ fontFamily: "'Playfair Display', serif" }}>
            Let's build something bespoke.
          </h2>
          <p className="text-white/80 mb-8">Tell us what you need and we'll have a proposal to you within 48 hours.</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button
              onClick={openChatbot}
              className="inline-flex items-center justify-center gap-2 font-bold text-sm px-8 py-4"
              style={{ background: "#F5A623", color: "#1a1a1a" }}
            >
              <MessageSquare size={18} /> Start the Conversation
            </button>
            <a
              href="mailto:info@elvorastrategies.com"
              className="inline-flex items-center justify-center gap-2 font-bold text-sm px-8 py-4 border-2 border-white text-white"
              style={{ background: "transparent" }}
            >
              info@elvorastrategies.com
            </a>
          </div>
        </div>
      </section>

      <footer className="py-8 px-6 text-center border-t" style={{ background: "#ffffff", borderColor: "#e0f2fe" }}>
        <p className="text-gray-400 text-sm">© {new Date().getFullYear()} Elvora Strategies. All rights reserved.</p>
      </footer>
    </div>
  );
}

