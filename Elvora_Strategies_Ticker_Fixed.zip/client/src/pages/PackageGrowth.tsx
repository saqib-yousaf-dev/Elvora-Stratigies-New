import { Link } from "wouter";
import { CheckCircle, ArrowLeft, MessageSquare } from "lucide-react";

const LOGO = "/manus-storage/elvora_logo_nobg_2db64aeb.png";

function openChatbot() {
  const el = document.getElementById("pulse-launcher");
  if (el) el.click();
}

const FEATURES = [
  { title: "Everything in Professional", desc: "Includes all Professional features: CRM connection, custom industry questions, appointment booking, priority support, and monthly performance review." },
  { title: "600 Conversations per Month", desc: "Covers up to 600 visitor interactions per month — ideal for growing firms with high enquiry volumes. Any extra conversations are billed at £0.50 each." },
  { title: "Advanced Qualification Flows", desc: "Multi-step, logic-driven qualification sequences that adapt based on visitor responses — ensuring only the most relevant leads reach your team." },
  { title: "Dedicated Onboarding Support", desc: "A dedicated onboarding specialist works with you through the entire setup process — from discovery call to go-live — ensuring Pulse is perfectly calibrated for your business." },
  { title: "Quarterly Strategy Review", desc: "Every quarter, we review your Pulse performance data with you and recommend improvements — new questions, updated flows, seasonal adjustments." },
];

const IDEAL_FOR = [
  "Growing firms handling 400+ enquiries per month",
  "Multi-service practices needing complex qualification logic",
  "Businesses scaling rapidly and needing a dedicated onboarding partner",
  "Teams that want quarterly strategic input on their AI performance",
  "Practices where lead quality matters as much as lead volume",
];

export default function PackageGrowth() {
  return (
    <div className="min-h-screen" style={{ background: "#f0f9ff" }}>
      {/* Navbar */}
      <nav className="sticky top-0 z-50 bg-white border-b px-6 lg:px-10 py-4 flex items-center justify-between" style={{ borderColor: "#e0f2fe" }}>
        <Link href="/">
          <span className="flex items-center gap-3 cursor-pointer">
            <img src={LOGO} alt="Elvora Strategies" className="h-9 w-auto" />
            <span className="font-black text-xl text-gray-900 uppercase tracking-widest" style={{ fontFamily: "'DM Sans', sans-serif" }}>
              Elvora <span style={{ color: "#F5A623" }}>Strategies</span>
            </span>
          </span>
        </Link>
        <Link href="/#pricing">
          <span className="flex items-center gap-2 text-sm font-semibold text-gray-600 hover:text-gray-900 cursor-pointer transition-colors">
            <ArrowLeft size={16} /> All Plans
          </span>
        </Link>
      </nav>

      {/* Hero */}
      <section className="py-20 px-6 lg:px-10" style={{ background: "linear-gradient(135deg, #0369a1 0%, #0284c7 50%, #0ea5e9 100%)" }}>
        <div className="max-w-4xl mx-auto text-center">
          <span className="text-xs font-bold tracking-widest uppercase mb-4 block text-white/70">Growth Plan</span>
          <h1 className="text-5xl lg:text-6xl font-bold text-white mb-4" style={{ fontFamily: "'Playfair Display', serif" }}>
            £199 <span className="text-3xl font-normal text-white/80">/ month</span>
          </h1>
          <p className="text-white/80 text-lg mb-2">or <strong className="text-white">£2,149 / year</strong> — save 10%</p>
          <p className="text-white/90 text-xl mt-6 max-w-2xl mx-auto">
            For growing firms handling higher enquiry volumes — advanced qualification, dedicated onboarding, and quarterly strategic reviews.
          </p>
          <button onClick={openChatbot} className="mt-10 inline-flex items-center justify-center gap-2 font-bold text-sm px-8 py-4 transition-all duration-200 active:scale-95" style={{ background: "#F5A623", color: "#1a1a1a" }}>
            <MessageSquare size={18} /> Book a Demo
          </button>
        </div>
      </section>

      {/* What's Included */}
      <section className="py-20 px-6 lg:px-10">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold text-gray-900 mb-12 text-center" style={{ fontFamily: "'Playfair Display', serif" }}>
            Everything in the <span style={{ color: "#0ea5e9" }}>Growth Plan</span>
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {FEATURES.map((f) => (
              <div key={f.title} className="bg-white p-8 border" style={{ borderTop: "3px solid #0ea5e9", borderColor: "#e0f2fe" }}>
                <div className="flex items-start gap-4">
                  <CheckCircle size={22} className="flex-shrink-0 mt-0.5" style={{ color: "#0ea5e9" }} />
                  <div>
                    <h3 className="font-bold text-gray-900 mb-2">{f.title}</h3>
                    <p className="text-gray-500 text-sm leading-relaxed">{f.desc}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Ideal For */}
      <section className="py-16 px-6 lg:px-10 bg-white">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-2xl font-bold text-gray-900 mb-8" style={{ fontFamily: "'Playfair Display', serif" }}>
            Ideal For
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {IDEAL_FOR.map((item) => (
              <div key={item} className="flex items-start gap-3 p-5 border" style={{ borderLeft: "3px solid #F5A623", borderColor: "#e0f2fe" }}>
                <CheckCircle size={16} className="flex-shrink-0 mt-0.5" style={{ color: "#F5A623" }} />
                <span className="text-gray-700 text-sm">{item}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Compare */}
      <section className="py-16 px-6 lg:px-10" style={{ background: "#f0f9ff" }}>
        <div className="max-w-4xl mx-auto flex flex-col sm:flex-row gap-4 justify-center text-center">
          <Link href="/packages/professional">
            <span className="font-bold text-sm cursor-pointer hover:underline text-gray-500">← Professional Plan</span>
          </Link>
          <span className="text-gray-300 hidden sm:block">|</span>
          <Link href="/packages/custom">
            <span className="font-bold text-sm cursor-pointer hover:underline" style={{ color: "#0ea5e9" }}>View the Custom Plan →</span>
          </Link>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 px-6 lg:px-10" style={{ background: "#0369a1" }}>
        <div className="max-w-2xl mx-auto text-center">
          <h2 className="text-3xl font-bold text-white mb-4" style={{ fontFamily: "'Playfair Display', serif" }}>
            Ready to scale?
          </h2>
          <p className="text-white/80 mb-8">Your AI receptionist can be live in under 2 weeks.</p>
          <button
            onClick={openChatbot}
            className="inline-flex items-center justify-center gap-2 font-bold text-sm px-8 py-4"
            style={{ background: "#F5A623", color: "#1a1a1a" }}
          >
            <MessageSquare size={18} /> Book a Demo
          </button>
        </div>
      </section>

      <footer className="py-8 px-6 text-center border-t" style={{ background: "#ffffff", borderColor: "#e0f2fe" }}>
        <p className="text-gray-400 text-sm">© {new Date().getFullYear()} Elvora Strategies. All rights reserved.</p>
      </footer>
    </div>
  );
}
