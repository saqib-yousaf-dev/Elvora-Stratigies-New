/**
 * Elvora Strategies — Pulse Signal redesign
 * GPTMate-inspired product narrative adapted to Elvora's sky blue, white and mango amber system.
 * No black backgrounds; Playfair Display provides editorial authority and DM Sans keeps the product UI clear.
*/
import { useEffect, useState } from "react";
import { Link } from "wouter";
import {
  Bot, Zap, Globe, Shield, ChevronRight, Mail,
  Linkedin, MessageSquare, Phone, ArrowRight, CheckCircle, Menu, X, Star, ChevronDown
} from "lucide-react";

const LOGO_TRANSPARENT = "/manus-storage/elvora_logo_nobg_2db64aeb.png";
const ABOUT_VISUAL = "/manus-storage/about_visual_60582e8c.jpg";
const PULSE_HERO = "/manus-storage/pulse_robot_hero_8c218dfe.png";
const HERO_VIDEO = "https://files.manuscdn.com/user_upload_by_module/session_file/310519663707500603/lhNDAmzIGTFKAdFt.mp4";

// Opens the Elvora chatbot widget programmatically
function openChatbot() {
  // The widget uses id="pulse-launcher" as the trigger button
  const launcher = document.getElementById("pulse-launcher");
  if (launcher) {
    launcher.click();
  }
}

const SERVICES = [
  {
    icon: Bot,
    title: "AI Chatbot Receptionist",
    desc: "Think of Pulse as your most capable receptionist — permanently at their desk, never off sick, never on lunch. The moment a visitor lands on your website, Pulse is there. It greets them, understands why they've come, and handles the conversation with the same warmth and professionalism you'd expect from your best member of staff. Whether someone arrives anxious, grieving, celebrating, or simply curious — Pulse reads the room and responds accordingly.",
    tag: "Core Service",
    color: "sky",
  },
  {
    icon: Zap,
    title: "Lead Qualification & Delivery",
    desc: "Pulse doesn't just take a message and hope for the best. It asks the right questions, in the right order, in the right tone — qualifying each visitor against your specific criteria before the conversation ends. The moment it's done, a clean, structured summary lands in your inbox or CRM. Not a raw chat log. A ready-to-act lead.",
    tag: "Lead Intelligence",
    color: "amber",
  },
  {
    icon: Bot,
    title: "Appointment Booking",
    desc: "Pulse connects to your calendar and books appointments in real time — no back-and-forth, no missed slots, no waiting until Monday morning. A client who decides at 10pm that they're ready to move forward can book their discovery call before they close the tab.",
    tag: "Scheduling",
    color: "sky",
  },
  {
    icon: Zap,
    title: "CRM & Inbox Integration",
    desc: "Every conversation Pulse has flows directly into your existing systems — your CRM, your inbox, your team's workflow. Fully formatted, tagged by enquiry type, and ready to act on. No manual data entry. No leads falling through the cracks. No chasing.",
    tag: "Integrations",
    color: "amber",
  },
];

const INDUSTRIES = [
  "Law Firms", "Insurance Brokers", "Estate Agents",
  "Financial Advisors", "Care Homes", "Accountants",
  "Medical Practices", "Consultancies",
];

const STATS = [
  { value: "24/7", label: "First Response" },
  { value: "Bespoke", label: "Built for You" },
  { value: "CRM", label: "Ready to Route" },
  { value: "Human", label: "Tone by Design" },
];

const PROCESS = [
  { step: "01", title: "Discovery Call", desc: "We learn your business, tone, and goals in a focused 30-minute session." },
  { step: "02", title: "Custom Build", desc: "Your AI receptionist is trained exclusively on your business — no generic scripts." },
  { step: "03", title: "Integration", desc: "We deploy seamlessly to your website and connect to your CRM or inbox." },
  { step: "04", title: "Go Live", desc: "Your AI receptionist starts capturing and qualifying leads from day one." },
];

const TICKER_ITEMS = [
  "Always On — 24/7", "Bespoke to Your Business", "Qualifies Every Visitor",
  "Books Appointments Live", "Flows Into Your CRM", "No Generic Scripts",
  "Deployed in Under 2 Weeks", "Reads the Room Every Time", "Never Misses an Enquiry",
  "Trained on Your Business", "Instant Lead Delivery", "Works While You Sleep",
];

// ─── Navbar ───────────────────────────────────────────────────────────────────
function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 60);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const navLinks = [
    { label: "Services", href: "#services" },
    { label: "How It Works", href: "#process" },
    { label: "Industries", href: "#industries" },
    { label: "Pricing", href: "#pricing" },
    { label: "About", href: "#about" },
    { label: "Contact", href: "#contact" },
    { label: "Blog", href: "/blog" },
  ];

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-400 ${
        scrolled
          ? "bg-white/95 backdrop-blur-xl shadow-sm shadow-sky-100/50"
          : "bg-white/95 backdrop-blur-xl"
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 lg:px-10 flex items-center justify-between h-20">
        <a href="#" className="flex items-center gap-3">
          <img src={LOGO_TRANSPARENT} alt="Elvora Strategies logo — AI chatbot and receptionist solutions" className="h-10 w-auto" />
          <span
            className={`font-bold text-xl tracking-tight transition-colors duration-300 ${
              "text-gray-900"
            }`}
            style={{ fontFamily: "'DM Sans', sans-serif" }}
          >
            Elvora <span style={{ color: "#F5A623" }}>Strategies</span>
          </span>
        </a>

        <nav className="hidden lg:flex items-center gap-8">
          {navLinks.map((l) => (
            <a
              key={l.label}
              href={l.href}
              className={`text-sm font-medium transition-colors duration-200 hover:text-amber-500 ${
                "text-gray-700"
              }`}
            >
              {l.label}
            </a>
          ))}
        </nav>

        <div className="hidden lg:flex items-center gap-4">
          <button
            onClick={openChatbot}
            className="font-semibold text-sm px-6 py-2.5 transition-all duration-200 active:scale-95"
            style={{ background: "#F5A623", color: "#1a1a1a", borderRadius: "2px" }}
          >
            Meet Pulse
          </button>

        </div>

        <button
          className="lg:hidden text-gray-900 transition-colors"
          onClick={() => setMenuOpen(!menuOpen)}
        >
          {menuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {menuOpen && (
        <div className="lg:hidden bg-white border-t border-sky-100 px-6 py-6 flex flex-col gap-4">
          {navLinks.map((l) => (
            <a
              key={l.label}
              href={l.href}
              onClick={() => setMenuOpen(false)}
              className="text-gray-800 font-medium py-2 border-b border-gray-100"
            >
              {l.label}
            </a>
          ))}
          <button
            onClick={() => { setMenuOpen(false); openChatbot(); }}
            className="mt-2 font-semibold text-sm px-6 py-3 text-center w-full"
            style={{ background: "#F5A623", color: "#1a1a1a" }}
          >
            Meet Pulse
          </button>

        </div>
      )}
    </header>
  );
}

// ─── Signal Bar ───────────────────────────────────────────────────────────────
function SignalBar() {
  return (
    <section className="pt-20" style={{ background: "#ffffff" }}>
      <div className="border-y" style={{ borderColor: "#bae6fd", background: "linear-gradient(90deg, #e0f2fe 0%, #ffffff 50%, #fffbeb 100%)" }}>
        <div className="max-w-7xl mx-auto px-6 lg:px-10 py-3 flex flex-col sm:flex-row items-center justify-between gap-2 text-center sm:text-left">
          <p className="text-sm font-medium text-slate-700">
            <span className="inline-flex w-2 h-2 rounded-full mr-2" style={{ background: "#0ea5e9" }} />
            Pulse is live — see how your website can respond while your team is busy.
          </p>
          <button onClick={openChatbot} className="text-sm font-bold inline-flex items-center gap-2 hover:underline" style={{ color: "#0369a1" }}>
            Try Pulse <ArrowRight size={15} />
          </button>
        </div>
      </div>
    </section>
  );
}

// ─── Hero ─────────────────────────────────────────────────────────────────────
function Hero() {
  return (
    <section className="relative overflow-hidden" style={{ background: "linear-gradient(135deg, #f7fcff 0%, #e0f2fe 58%, #fffbeb 100%)" }}>
      <div className="absolute top-0 right-0 w-[38%] h-full hidden lg:block" style={{ background: "radial-gradient(circle at 65% 25%, rgba(245,166,35,0.20), transparent 34%), radial-gradient(circle at 35% 70%, rgba(14,165,233,0.22), transparent 45%)" }} />
      <div className="relative max-w-7xl mx-auto px-6 lg:px-10 py-20 lg:py-28">
        <div className="grid lg:grid-cols-[1.05fr_0.95fr] gap-12 lg:gap-20 items-center">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 border px-3 py-2 mb-8" style={{ borderColor: "#bae6fd", background: "#ffffff" }}>
              <span className="w-2 h-2 rounded-full" style={{ background: "#0ea5e9" }} />
              <span className="text-xs font-bold tracking-[0.14em] uppercase text-slate-600">A trained AI receptionist for your website</span>
            </div>
            <h1 className="text-5xl sm:text-6xl lg:text-7xl font-bold text-slate-950 leading-[0.98] tracking-tight mb-7" style={{ fontFamily: "'Playfair Display', serif" }}>
              Every visitor deserves a <span style={{ color: "#0284c7" }}>first response.</span>
            </h1>
            <p className="text-slate-600 text-lg lg:text-xl leading-relaxed max-w-2xl mb-8">
              Pulse handles the opening conversation when your team is busy — answering relevant questions, understanding the enquiry and handing over the details that matter.
            </p>
            <div className="flex flex-col sm:flex-row gap-3 mb-9">
              <button onClick={openChatbot} className="inline-flex items-center justify-center gap-2 font-bold text-sm px-7 py-4 transition-all duration-200 active:scale-95" style={{ background: "#F5A623", color: "#1a1a1a" }}>
                Try Pulse <ArrowRight size={18} />
              </button>
              <a href="#pricing" className="inline-flex items-center justify-center gap-2 border font-bold text-sm px-7 py-4 text-slate-700 transition-colors hover:border-sky-400" style={{ borderColor: "#7dd3fc", background: "#ffffff" }}>
                Explore plans <ChevronRight size={18} />
              </a>
            </div>
            <div className="flex flex-wrap gap-x-5 gap-y-2">
              {["Trained on your business", "Routes to inbox or CRM", "Built for sensitive enquiries"].map((item) => (
                <div key={item} className="flex items-center gap-2 text-sm text-slate-600"><CheckCircle size={15} style={{ color: "#0ea5e9" }} />{item}</div>
              ))}
            </div>
          </div>

          <div className="relative">
            <div className="absolute -inset-4 border hidden sm:block" style={{ borderColor: "#bae6fd" }} />
            <div className="relative overflow-hidden border bg-white shadow-[0_24px_70px_rgba(14,165,233,0.14)]" style={{ borderColor: "#bae6fd" }}>
              <div className="relative h-44 overflow-hidden" style={{ background: "#0369a1" }}>
                <video autoPlay muted loop playsInline className="w-full h-full object-cover opacity-55" src={HERO_VIDEO} />
                <div className="absolute inset-0" style={{ background: "linear-gradient(90deg, rgba(3,105,161,0.88), rgba(14,165,233,0.34))" }} />
                <div className="absolute left-6 bottom-6 text-white">
                  <p className="text-xs uppercase tracking-[0.16em] font-bold text-sky-100 mb-2">Pulse is live</p>
                  <p className="text-2xl font-bold" style={{ fontFamily: "'Playfair Display', serif" }}>A better first conversation.</p>
                </div>
              </div>
              <div className="p-6 lg:p-8">
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-10 h-10 flex items-center justify-center" style={{ background: "#e0f2fe" }}><Bot size={20} style={{ color: "#0284c7" }} /></div>
                  <div><p className="font-bold text-slate-900">Pulse</p><p className="text-xs text-slate-500">Your AI receptionist</p></div>
                  <span className="ml-auto text-xs font-semibold px-2 py-1" style={{ background: "#dcfce7", color: "#15803d" }}>Online</span>
                </div>
                <div className="space-y-3 text-sm leading-relaxed">
                  <div className="max-w-[88%] p-4 text-slate-700" style={{ background: "#f0f9ff" }}>Hi, I’m Pulse. How can I help with your enquiry today?</div>
                  <div className="ml-auto max-w-[82%] p-4 text-slate-700 border" style={{ background: "#ffffff", borderColor: "#e5e7eb" }}>I’d like to understand whether your service is right for me.</div>
                  <div className="max-w-[88%] p-4 text-slate-700" style={{ background: "#f0f9ff" }}>Of course. I can explain how it works and make sure the right person receives your enquiry.</div>
                </div>
                <button onClick={openChatbot} className="mt-6 w-full py-3.5 text-sm font-bold transition-all duration-200 active:scale-95" style={{ background: "#0284c7", color: "#ffffff" }}>Open a conversation with Pulse</button>
              </div>
            </div>
          </div>
        </div>
        <div className="mt-16 grid grid-cols-2 lg:grid-cols-4 border-t border-l" style={{ borderColor: "#bae6fd" }}>
          {STATS.map((s) => (
            <div key={s.label} className="p-5 lg:p-6 bg-white/70 border-r border-b" style={{ borderColor: "#bae6fd" }}>
              <div className="text-2xl lg:text-3xl font-bold text-slate-900 mb-1" style={{ fontFamily: "'Playfair Display', serif" }}>{s.value}</div>
              <div className="text-xs font-bold tracking-[0.13em] uppercase" style={{ color: "#0284c7" }}>{s.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ─── Ticker ───────────────────────────────────────────────────────────────────
function Ticker() {
  const items = [...TICKER_ITEMS, ...TICKER_ITEMS];
  return (
    <div className="py-4 overflow-hidden border-y" style={{ background: "#ffffff", borderColor: "#bae6fd" }}>
      <div
        className="flex gap-12 whitespace-nowrap"
        style={{ animation: "ticker 30s linear infinite", width: "max-content" }}
      >
        {items.map((item, i) => (
          <span key={i} className="flex items-center gap-3 text-sm font-medium tracking-wide" style={{ color: "#0369a1" }}>
            <span className="w-1 h-1 rounded-full flex-shrink-0" style={{ background: "#F5A623" }} />
            {item}
          </span>
        ))}
      </div>
    </div>
  );
}

// ─── Services ─────────────────────────────────────────────────────────────────
function ServiceCard({ s, index }: { s: typeof SERVICES[0]; index: number }) {
  const [open, setOpen] = useState(false);
  const Icon = s.icon;
  const isBlue = s.color === "sky";
  return (
    <div
      className="border bg-white transition-all duration-300"
      style={{
        borderColor: "#e0f2fe",
        borderTop: isBlue ? "3px solid #0ea5e9" : "3px solid #F5A623",
      }}
    >
      {/* Collapsed header — always visible */}
      <button
        className="w-full flex items-center gap-5 p-8 text-left"
        onClick={() => setOpen(!open)}
        aria-expanded={open}
      >
        <div
          className="flex-shrink-0 inline-flex items-center justify-center w-12 h-12"
          style={{ background: isBlue ? "#e0f2fe" : "#fef3c7" }}
        >
          <Icon size={22} style={{ color: isBlue ? "#0284c7" : "#d97706" }} />
        </div>
        <div className="flex-1 min-w-0">
          <span
            className="text-xs font-bold tracking-widest uppercase mb-1 block"
            style={{ color: isBlue ? "#0ea5e9" : "#d97706" }}
          >
            {s.tag}
          </span>
          <h3
            className="text-xl font-bold text-gray-900"
            style={{ fontFamily: "'Playfair Display', serif" }}
          >
            {s.title}
          </h3>
        </div>
        <ChevronDown
          size={20}
          className="flex-shrink-0 transition-transform duration-300"
          style={{
            color: "#6b7280",
            transform: open ? "rotate(180deg)" : "rotate(0deg)",
          }}
        />
      </button>

      {/* Expandable body */}
      <div
        className="overflow-hidden transition-all duration-400"
        style={{ maxHeight: open ? "400px" : "0px" }}
      >
        <div className="px-8 pb-8 pt-0">
          <div className="border-t pt-6" style={{ borderColor: "#e0f2fe" }}>
            <p className="text-sm leading-loose text-gray-500 mb-6">{s.desc}</p>
            <button
              onClick={openChatbot}
              className="inline-flex items-center gap-2 text-sm font-bold px-6 py-3 transition-all duration-200 active:scale-95"
              style={{ background: isBlue ? "#0284c7" : "#F5A623", color: isBlue ? "#ffffff" : "#1a1a1a" }}
            >
              See Pulse in action <ArrowRight size={15} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function Services() {
  return (
    <section id="services" className="py-28 bg-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-10">
        <div className="grid lg:grid-cols-[0.92fr_1.08fr] gap-8 lg:gap-20 items-end mb-16">
          <div>
            <span className="text-xs font-bold tracking-widest uppercase mb-3 block" style={{ color: "#0ea5e9" }}>What Pulse Does</span>
            <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 max-w-xl leading-tight" style={{ fontFamily: "'Playfair Display', serif" }}>
              One AI Receptionist. <span className="relative inline-block">Every Capability You Need.<span className="absolute -bottom-1 left-0 right-0 h-0.5" style={{ background: "#F5A623" }} /></span>
            </h2>
          </div>
          <div className="lg:border-l lg:pl-10" style={{ borderColor: "#bae6fd" }}>
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-[0.14em] mb-3" style={{ color: "#0284c7" }}><span className="w-2 h-2 rounded-full" style={{ background: "#0ea5e9" }} />Pulse capability map</div>
            <p className="text-gray-500 max-w-xl text-lg">Pulse is trained around your business and can take the first conversation from question to informed handover. Open a capability to see the conversation behind it.</p>
          </div>
        </div>
        <div className="flex flex-col gap-4">
          {SERVICES.map((s, i) => (
            <ServiceCard key={s.title} s={s} index={i} />
          ))}
        </div>
      </div>
    </section>
  );
}

// ─── How It Works ─────────────────────────────────────────────────────────────
function Process() {
  const [showHow, setShowHow] = useState(false);
  const [enquiries, setEnquiries] = useState(50);
  const [dealValue, setDealValue] = useState(2500);
  const monthlyRevenue = Math.round(enquiries * dealValue * 0.30);
  const annualRevenue = monthlyRevenue * 12;
  return (
    <section id="process" className="py-28 border-y" style={{ background: "#f8fbff", borderColor: "#e0f2fe" }}>
      <div className="max-w-7xl mx-auto px-6 lg:px-10">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div>
            <span className="text-xs font-bold tracking-widest uppercase mb-3 block" style={{ color: "#0ea5e9" }}>
              How It Works
            </span>
            <h2
              className="text-4xl lg:text-5xl font-bold text-gray-900 leading-tight mb-6"
              style={{ fontFamily: "'Playfair Display', serif" }}
            >
              From Discovery to{" "}
              <span style={{ color: "#F5A623" }}>Live in Days</span>
            </h2>
            <p className="text-gray-500 text-lg leading-relaxed mb-10">
              We turn your business knowledge into a live first-response system — from discovery, through training, to a clear handover for your team.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <button
                onClick={openChatbot}
                className="inline-flex items-center gap-2 font-bold px-8 py-4 transition-all duration-200 active:scale-95"
                style={{ background: "#F5A623", color: "#1a1a1a" }}
              >
                Meet Pulse <ArrowRight size={18} />
              </button>
              <button
                onClick={() => setShowHow(!showHow)}
                className="inline-flex items-center gap-2 font-bold px-8 py-4 border transition-all duration-200 active:scale-95"
                style={{ borderColor: "#0284c7", color: "#0284c7", background: "transparent" }}
              >
                See the Pulse flow <ChevronDown size={18} style={{ transform: showHow ? "rotate(180deg)" : "rotate(0deg)", transition: "transform 0.3s" }} />
              </button>
            </div>

            {/* Hidden section revealed on See How */}
            <div
              className="overflow-hidden transition-all duration-500"
              style={{ maxHeight: showHow ? "800px" : "0px", marginTop: showHow ? "2rem" : "0" }}
            >
              <div className="p-6 border" style={{ borderColor: "#bae6fd", background: "#ffffff" }}>
                <div className="flex flex-col gap-4 mb-6">
                  {PROCESS.map((p) => (
                    <div key={p.step} className="flex gap-4 items-start">
                      <div
                        className="flex-shrink-0 w-9 h-9 flex items-center justify-center font-bold text-xs"
                        style={{ background: "#F5A623", color: "#1a1a1a" }}
                      >
                        {p.step}
                      </div>
                      <div>
                        <h4 className="font-bold text-gray-900 text-sm mb-0.5" style={{ fontFamily: "'Playfair Display', serif" }}>
                          {p.title}
                        </h4>
                        <p className="text-gray-500 text-xs leading-relaxed">{p.desc}</p>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="border-t pt-4" style={{ borderColor: "#e0f2fe" }}>
                  <p className="text-gray-600 text-sm mb-4">Want to see how this would work for your business?</p>
                  <div className="flex flex-col sm:flex-row gap-3">
                  <button
                    onClick={openChatbot}
                    className="flex-1 inline-flex items-center justify-center gap-2 font-bold text-sm px-6 py-3 transition-all duration-200 active:scale-95"
                    style={{ background: "#0284c7", color: "#ffffff" }}
                  >
                    <MessageSquare size={16} /> Open Pulse
                  </button>
                  <a
                    href="tel:+441615150022"
                    className="flex-1 inline-flex items-center justify-center gap-2 font-bold text-sm px-6 py-3 border transition-all duration-200 active:scale-95"
                    style={{ borderColor: "#0284c7", color: "#0284c7", background: "transparent" }}
                  >
                    Call Us Now
                  </a>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="flex flex-col gap-5">
            {/* ROI Calculator */}
            <div className="bg-white border p-8" style={{ borderColor: "#bae6fd", borderTop: "3px solid #0ea5e9" }}>
              <h3 className="text-2xl font-bold text-gray-900 mb-2" style={{ fontFamily: "'Playfair Display', serif" }}>
                Calculate Your Impact
              </h3>
              <p className="text-gray-500 text-sm mb-8">See how much revenue Pulse could unlock for your business.</p>

              {/* Monthly Enquiries */}
              <div className="mb-6">
                <label className="text-sm font-semibold text-gray-700 block mb-2">Monthly Missed Enquiries</label>
                <input
                  type="number"
                  min={0}
                  value={enquiries}
                  onChange={e => setEnquiries(Math.max(0, Number(e.target.value)))}
                  placeholder="e.g. 50"
                  className="w-full px-4 py-3 border text-gray-900 text-lg font-semibold focus:outline-none focus:ring-2"
                  style={{ borderColor: "#bae6fd", borderRadius: "2px" }}
                />
              </div>

              {/* Average Deal Value */}
              <div className="mb-8">
                <label className="text-sm font-semibold text-gray-700 block mb-2">Average Deal Value (£)</label>
                <div className="relative">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500 font-semibold text-lg">£</span>
                  <input
                    type="number"
                    min={0}
                    value={dealValue}
                    onChange={e => setDealValue(Math.max(0, Number(e.target.value)))}
                    placeholder="e.g. 2500"
                    className="w-full pl-8 pr-4 py-3 border text-gray-900 text-lg font-semibold focus:outline-none focus:ring-2"
                    style={{ borderColor: "#bae6fd", borderRadius: "2px" }}
                  />
                </div>
              </div>

              {/* Result */}
              <div className="p-6 text-center" style={{ background: "#f0f9ff", borderTop: "3px solid #F5A623" }}>
                <p className="text-xs font-bold tracking-widest uppercase mb-2" style={{ color: "#0ea5e9" }}>
                  Potential Monthly Revenue Increase
                </p>
                <p className="text-5xl font-black mb-1" style={{ fontFamily: "'Playfair Display', serif", color: "#0284c7" }}>
                  +£{monthlyRevenue.toLocaleString()}<span className="text-2xl font-bold"> / mo.</span>
                </p>
                <p className="text-sm font-semibold mt-1" style={{ color: "#F5A623" }}>
                  +£{annualRevenue.toLocaleString()} per year
                </p>
                <p className="text-xs text-gray-400 mt-2">Based on a typical 30% conversion rate.</p>
              </div>

              <button
                onClick={openChatbot}
                className="mt-6 w-full py-4 font-bold text-sm tracking-wide transition-all duration-200 active:scale-95"
                style={{ background: "#F5A623", color: "#1a1a1a" }}
              >
                Ask Pulse about your opportunity
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

// ─── Industries ───────────────────────────────────────────────────────────────
function Industries() {
  return (
    <section id="industries" className="py-28 bg-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-10">
        <div className="mb-16">
          <span className="text-xs font-bold tracking-widest uppercase mb-3 block" style={{ color: "#0ea5e9" }}>
            Industries We Serve
          </span>
          <h2
            className="text-4xl lg:text-5xl font-bold text-gray-900"
            style={{ fontFamily: "'Playfair Display', serif" }}
          >
            Built for Businesses That{" "}
            <span className="relative inline-block">
              Can't Miss a Lead
              <span className="absolute -bottom-1 left-0 right-0 h-0.5" style={{ background: "#F5A623" }} />
            </span>
          </h2>
        </div>

        <div className="flex flex-wrap gap-3 mb-16">
          {INDUSTRIES.map((ind) => (
            <div
              key={ind}
              className="px-6 py-3 border font-medium text-sm transition-all duration-200 cursor-default tracking-wide text-gray-700 hover:text-gray-900"
              style={{ borderColor: "#bae6fd", background: "#f0f9ff" }}
              onMouseEnter={e => {
                (e.currentTarget as HTMLDivElement).style.borderColor = "#F5A623";
                (e.currentTarget as HTMLDivElement).style.background = "#fffbeb";
              }}
              onMouseLeave={e => {
                (e.currentTarget as HTMLDivElement).style.borderColor = "#bae6fd";
                (e.currentTarget as HTMLDivElement).style.background = "#f0f9ff";
              }}
            >
              {ind}
            </div>
          ))}
        </div>

        {/* Pulse signal strip */}
        <div
          className="p-10 lg:p-14 flex flex-col lg:flex-row items-center justify-between gap-8 border-y"
          style={{ background: "#ffffff", borderColor: "#bae6fd" }}
        >
          <div>
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-[0.14em] mb-3" style={{ color: "#0284c7" }}><span className="w-2 h-2 rounded-full" style={{ background: "#0ea5e9" }} />Pulse learns your context</div>
            <h3 className="text-2xl lg:text-3xl font-bold text-slate-900 mb-2" style={{ fontFamily: "'Playfair Display', serif" }}>
              Don't see your industry?
            </h3>
            <p className="text-slate-500 max-w-xl">
              Pulse is built around your services, language and customer journey — not a generic industry template.
            </p>
          </div>
          <button
            onClick={openChatbot}
            className="flex-shrink-0 font-bold px-8 py-4 transition-all duration-200 active:scale-95 whitespace-nowrap"
            style={{ background: "#F5A623", color: "#1a1a1a" }}
          >
            Ask Pulse about your industry
          </button>
        </div>
      </div>
    </section>
  );
}

// ─── About ────────────────────────────────────────────────────────────────────
function About() {
  return (
    <section id="about" className="py-28" style={{ background: "#ffffff" }}>
      <div className="max-w-7xl mx-auto px-6 lg:px-10">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div className="relative">
            <div className="overflow-hidden aspect-[4/3] bg-sky-100">
              {/* Image removed */}
            </div>
            <div
              className="absolute -bottom-6 -right-6 bg-white shadow-xl p-6 max-w-xs"
              style={{ borderLeft: "4px solid #F5A623" }}
            >
              <div className="text-4xl font-bold text-gray-900 mb-1" style={{ fontFamily: "'Playfair Display', serif" }}>
                100%
              </div>
              <div className="text-gray-500 text-sm">Bespoke — every AI assistant is built and trained exclusively for your business.</div>
            </div>
          </div>

          <div>
            <span className="text-xs font-bold tracking-widest uppercase mb-3 block" style={{ color: "#0ea5e9" }}>
              About Elvora Strategies
            </span>
            <h2
              className="text-4xl lg:text-5xl font-bold text-gray-900 leading-tight mb-6"
              style={{ fontFamily: "'Playfair Display', serif" }}
            >
              We Build AI That Works{" "}
              <span style={{ color: "#F5A623" }}>For Your Business</span>
            </h2>
            <p className="text-gray-600 text-lg leading-relaxed mb-6">
              Elvora Strategies is an AI automation agency specialising in custom AI-powered chatbot
              receptionists. Every client gets a bespoke AI assistant trained specifically on their
              business — not a generic template, not a chatbot that frustrates visitors.
            </p>
            <p className="text-gray-500 leading-relaxed mb-8">
              We work with law firms, estate agents, care homes, financial advisors, and any business
            that receives enquiries and wants to convert them faster. Based in Manchester and serving businesses across the Northwest and beyond, our AI receptionists greet
            visitors, hold genuine consultative conversations, and deliver qualified leads directly
            to you — 24 hours a day, 7 days a week. Whether you’re a law firm in Manchester, an estate agent in the Northwest, or an accountant looking to capture every enquiry, we build the AI receptionist for small business that actually works.
          </p>

          {/* Calls and Pulse */}
          <div
            className="rounded-xl p-5 mb-8 flex gap-4 items-start"
            style={{ background: "#e0f2fe", borderLeft: "4px solid #F5A623" }}
          >
            <MessageSquare size={22} className="mt-0.5 flex-shrink-0" style={{ color: "#0ea5e9" }} />
            <div>
              <p className="font-bold text-gray-800 text-sm mb-1">Calls are always welcome</p>
              <p className="text-gray-600 text-sm leading-relaxed">
                You are always welcome to call us. We use <strong>Pulse</strong> as our first point of contact because it is trained on our business and can answer most questions immediately, day or night. We believe in the service we provide to our clients — so we use it ourselves. If you would prefer to speak with our team, call <a href="tel:+441615150022" className="font-semibold underline" style={{ color: "#0284c7" }}>01615 150022</a> or send us a message on WhatsApp.
              </p>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-4">
              <button
                onClick={openChatbot}
                className="inline-flex items-center gap-2 font-bold px-8 py-4 transition-all duration-200 active:scale-95"
                style={{ background: "#F5A623", color: "#1a1a1a" }}
              >
                Meet Pulse <ArrowRight size={18} />
              </button>
              <a
                href="https://wa.me/447930234660"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 border-2 font-semibold px-8 py-4 transition-all duration-200 text-gray-700 hover:text-gray-900"
                style={{ borderColor: "#bae6fd" }}
              >
                <MessageSquare size={18} className="text-green-500" />
                WhatsApp Us
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

// ─── Pricing ──────────────────────────────────────────────────────────────────
const PRICING_TIERS = [
  {
    name: "Starter",
    monthlyPrice: "£99",
    annualPrice: "£1,069",
    annualMonthly: "£89",
    setupFee: "£100",
    period: "/month",
    tagline: "Perfect for solo practitioners and small offices",
    highlight: false,
    packageUrl: "/packages/starter",
    features: [
      "One custom AI receptionist, trained on your business",
      "Lead capture to your inbox, 24/7",
      "250 conversations per month",
      "Standard setup & onboarding",
      "Email support",
    ],
  },
  {
    name: "Professional",
    monthlyPrice: "£149",
    annualPrice: "£1,609",
    annualMonthly: "£134",
    setupFee: "£100",
    period: "/month",
    tagline: "Ideal for busy practices",
    highlight: true,
    packageUrl: "/packages/professional",
    features: [
      "Everything in Starter",
      "CRM connection",
      "Custom industry-specific questions",
      "Appointment booking integration",
      "400 conversations per month",
      "Priority support",
      "Monthly performance review",
    ],
  },
  {
    name: "Growth",
    monthlyPrice: "£199",
    annualPrice: "£2,149",
    annualMonthly: "£179",
    setupFee: "£100",
    period: "/month",
    tagline: "For growing firms handling higher enquiry volumes",
    highlight: false,
    packageUrl: "/packages/growth",
    features: [
      "Everything in Professional",
      "600 conversations per month",
      "Advanced qualification flows",
      "Dedicated onboarding support",
      "Quarterly strategy review",
    ],
  },
  {
    name: "Custom",
    monthlyPrice: "Let's Talk",
    annualPrice: "Let's Talk",
    annualMonthly: "",
    period: "",
    tagline: "Built entirely around your business needs",
    highlight: false,
    isCustom: true,
    packageUrl: "/packages/custom",
    features: [
      "Everything in Growth",
      "Unlimited conversations",
      "Multi-location deployment",
      "Custom integrations & workflows",
      "Dedicated account manager",
      "SLA-backed support",
    ],
  },
];

function Pricing() {
  const [annual, setAnnual] = useState(false);
  return (
    <section id="pricing" className="py-28 border-y" style={{ background: "#ffffff", borderColor: "#e0f2fe" }}>
      <div className="max-w-7xl mx-auto px-6 lg:px-10">
        <div className="grid lg:grid-cols-[0.85fr_1.15fr] gap-8 lg:gap-20 items-end mb-10">
          <div>
            <span className="text-xs font-bold tracking-widest uppercase mb-3 block" style={{ color: "#0ea5e9" }}>Simple, Transparent Pricing</span>
            <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 leading-tight" style={{ fontFamily: "'Playfair Display', serif" }}>One Product. <span style={{ color: "#F5A623" }}>Four Tiers.</span></h2>
          </div>
          <div className="lg:border-l lg:pl-10" style={{ borderColor: "#bae6fd" }}>
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-[0.14em] mb-3" style={{ color: "#0284c7" }}><span className="w-2 h-2 rounded-full" style={{ background: "#0ea5e9" }} />Choose your Pulse capacity</div>
            <p className="text-gray-500 max-w-xl text-lg">Every plan includes a bespoke receptionist trained on your business. Start where your enquiry volume is today, then grow when you need to.</p>
          </div>
        </div>
        {/* Monthly / Annual toggle */}
        <div className="flex items-center justify-center gap-4 mb-12 flex-wrap">
          <span className="text-base font-bold" style={{ color: annual ? "#9ca3af" : "#111827" }}>Monthly</span>
          <button
            onClick={() => setAnnual(!annual)}
            className="relative w-16 h-8 rounded-full transition-colors duration-200 focus:outline-none flex-shrink-0"
            style={{ background: annual ? "#0284c7" : "#d1d5db" }}
            aria-label="Toggle annual billing"
          >
            <span
              className="absolute top-1 w-6 h-6 rounded-full bg-white shadow transition-transform duration-200"
              style={{ left: annual ? "calc(100% - 1.75rem)" : "0.25rem" }}
            />
          </button>
          <span className="text-base font-bold" style={{ color: annual ? "#111827" : "#9ca3af" }}>
            Annual{" "}
            <span className="ml-1 px-2 py-1 text-xs font-bold rounded-full" style={{ background: "#F5A623", color: "#1a1a1a" }}>Save 10%</span>
          </span>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 items-start">
          {PRICING_TIERS.map((tier) => {
            const displayPrice = annual ? (tier as any).annualMonthly || (tier as any).annualPrice : (tier as any).monthlyPrice;
            return (
            <div
              key={tier.name}
              className="relative flex flex-col p-8 border transition-all duration-300 hover:-translate-y-1 hover:shadow-xl"
              style={{
                background: tier.highlight ? "#0284c7" : "#ffffff",
                borderColor: tier.highlight ? "#0284c7" : "#e0f2fe",
                borderTop: tier.highlight ? "3px solid #F5A623" : "3px solid #0ea5e9",
              }}
            >
              {tier.highlight && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 flex items-center gap-1 px-3 py-1 text-xs font-bold tracking-widest uppercase" style={{ background: "#F5A623", color: "#1a1a1a" }}>
                  <Star size={10} fill="#1a1a1a" /> Most Popular
                </div>
              )}
              <span className="text-xs font-bold tracking-widest uppercase mb-4 block" style={{ color: tier.highlight ? "#bae6fd" : "#0ea5e9" }}>
                {tier.name}
              </span>
              <div className="mb-1 flex items-end gap-1">
                <span className="text-5xl font-black" style={{ fontFamily: "'Playfair Display', serif", color: tier.highlight ? "#ffffff" : "#111827" }}>
                  {displayPrice}
                </span>
                {!(tier as any).isCustom && (
                  <span className="text-base mb-2" style={{ color: tier.highlight ? "#bae6fd" : "#6b7280" }}>/mo</span>
                )}
              </div>
              {annual && !(tier as any).isCustom && (tier as any).annualMonthly && (
                <p className="text-xs mb-1" style={{ color: tier.highlight ? "#bae6fd" : "#6b7280" }}>
                  Billed as {(tier as any).annualPrice}/year
                </p>
              )}
              {!(tier as any).isCustom && (
                <p className="text-xs mb-1" style={{ color: tier.highlight ? "#bae6fd" : "#6b7280" }}>
                  + {(tier as any).setupFee} setup fee
                </p>
              )}
              <p className="text-sm mb-8 mt-2" style={{ color: tier.highlight ? "#e0f2fe" : "#6b7280" }}>{tier.tagline}</p>
              <ul className="flex flex-col gap-3 mb-10 flex-1">
                {tier.features.map((f) => (
                  <li key={f} className="flex items-start gap-3 text-sm">
                    <CheckCircle size={16} className="flex-shrink-0 mt-0.5" style={{ color: tier.highlight ? "#F5A623" : "#0ea5e9" }} />
                    <span style={{ color: tier.highlight ? "#e0f2fe" : "#374151" }}>{f}</span>
                  </li>
                ))}
              </ul>
              {(tier as any).isCustom ? (
                <div className="flex flex-col gap-2">
                  <button
                    onClick={openChatbot}
                    className="w-full py-3 font-bold text-sm tracking-wide transition-all duration-200 active:scale-95"
                    style={{ background: "#F5A623", color: "#1a1a1a" }}
                  >
                    Tell Us What You Need
                  </button>
                  <Link href={(tier as any).packageUrl}>
                    <span className="block w-full py-2 text-center text-xs font-semibold cursor-pointer hover:underline transition-colors" style={{ color: "#0ea5e9" }}>
                      Learn More →
                    </span>
                  </Link>
                </div>
              ) : (
                <div className="flex flex-col gap-2">
                  <button
                    onClick={openChatbot}
                    className="w-full py-3 font-bold text-sm tracking-wide transition-all duration-200 active:scale-95"
                    style={tier.highlight ? { background: "#F5A623", color: "#1a1a1a" } : { background: "#0284c7", color: "#ffffff" }}
                  >
                    Ask Pulse about this plan
                  </button>
                  <Link href={(tier as any).packageUrl}>
                    <span className="block w-full py-2 text-center text-xs font-semibold cursor-pointer hover:underline transition-colors" style={{ color: tier.highlight ? "#bae6fd" : "#0ea5e9" }}>
                      Learn More →
                    </span>
                  </Link>
                </div>
              )}
           </div>
            );
          })}
       </div>
        <div className="mt-10 text-center">
          <p className="text-gray-500 text-sm mb-2">
            Your assistant never stops working — any conversations beyond your monthly allowance are billed at{" "}
            <span className="font-semibold text-gray-700">£0.50 each</span>.
          </p>
          <p className="text-gray-500 text-sm">
            Every business is different — if your needs sit outside these tiers,{" "}
            <button onClick={openChatbot} className="underline font-semibold hover:text-gray-800 transition-colors" style={{ color: "#0284c7" }}>
              book a demo
            </button>{" "}
            and we'll build a package around you.
          </p>
        </div>
      </div>
    </section>
  );
}

// ─── White Labelling ────────────────────────────────────────────────────────────
function WhiteLabelling() {
  return (
    <section id="white-labelling" className="py-28" style={{ background: "#f8fbff" }}>
      <div className="max-w-7xl mx-auto px-6 lg:px-10">
        <div className="mb-16 text-center">
          <span className="text-xs font-bold tracking-widest uppercase mb-3 block" style={{ color: "#0ea5e9" }}>
            Partnership Opportunity
          </span>
          <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 leading-tight" style={{ fontFamily: "'Playfair Display', serif" }}>
            White Label{" "}<span style={{ color: "#F5A623" }}>Pulse</span>
          </h2>
          <p className="text-gray-600 mt-4 max-w-2xl mx-auto text-lg">
            Resell Pulse under your own brand. We handle the technology. You own the client relationship.
          </p>
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <h3 className="text-2xl font-bold text-gray-900 mb-6" style={{ fontFamily: "'Playfair Display', serif" }}>Why Partner With Us?</h3>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 mt-1" style={{ background: "#0ea5e9" }}>
                  <span className="text-white text-sm font-bold">✓</span>
                </div>
                <div>
                  <p className="font-semibold text-gray-900">Your Branding, Our Technology</p>
                  <p className="text-gray-600 text-sm">Fully white-labelled interface with your logo, colours, and messaging.</p>
                </div>
              </li>
              <li className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 mt-1" style={{ background: "#0ea5e9" }}>
                  <span className="text-white text-sm font-bold">✓</span>
                </div>
                <div>
                  <p className="font-semibold text-gray-900">Recurring Revenue Stream</p>
                  <p className="text-gray-600 text-sm">Margin-based pricing model. You set your margins, we handle delivery.</p>
                </div>
              </li>
              <li className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 mt-1" style={{ background: "#0ea5e9" }}>
                  <span className="text-white text-sm font-bold">✓</span>
                </div>
                <div>
                  <p className="font-semibold text-gray-900">Zero Technical Overhead</p>
                  <p className="text-gray-600 text-sm">We manage infrastructure, updates, support, and compliance. You focus on sales.</p>
                </div>
              </li>
              <li className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 mt-1" style={{ background: "#0ea5e9" }}>
                  <span className="text-white text-sm font-bold">✓</span>
                </div>
                <div>
                  <p className="font-semibold text-gray-900">Dedicated Partner Support</p>
                  <p className="text-gray-600 text-sm">Direct access to our team for onboarding, training, and account management.</p>
                </div>
              </li>
            </ul>
          </div>
          <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-10 rounded-lg border-l-4" style={{ borderColor: "#F5A623" }}>
            <h3 className="text-2xl font-bold text-gray-900 mb-8" style={{ fontFamily: "'Playfair Display', serif" }}>Perfect For</h3>
            <ul className="space-y-3 mb-8">
              <li className="text-gray-700 flex items-center gap-2">
                <span style={{ color: "#F5A623" }}>→</span> Digital agencies expanding service offerings
              </li>
              <li className="text-gray-700 flex items-center gap-2">
                <span style={{ color: "#F5A623" }}>→</span> Consultancies adding AI automation to their toolkit
              </li>
              <li className="text-gray-700 flex items-center gap-2">
                <span style={{ color: "#F5A623" }}>→</span> Web design firms offering AI receptionists to clients
              </li>
              <li className="text-gray-700 flex items-center gap-2">
                <span style={{ color: "#F5A623" }}>→</span> CRM providers integrating AI lead capture
              </li>
              <li className="text-gray-700 flex items-center gap-2">
                <span style={{ color: "#F5A623" }}>→</span> Industry-specific software platforms
              </li>
            </ul>
            <button
              onClick={() => document.getElementById("pulse-launcher")?.click()}
              className="w-full py-3 font-bold text-sm tracking-wide transition-all duration-200 active:scale-95"
              style={{ background: "#F5A623", color: "#1a1a1a" }}
            >
              Explore Partnership
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}

// ─── Testimonials ─────────────────────────────────────────────────────────────
const TESTIMONIALS = [
  {
    industry: "Law Firm",
    location: "Manchester",
    result: "34 qualified leads in the first 30 days",
    quote: "We handle a high volume of sensitive enquiries — redundancy, divorce, employment disputes. Pulse handles every one of them with exactly the right tone. It doesn't rush people. It doesn't sound robotic. And every morning we have a clean list of qualified leads waiting for us.",
    metric: "34",
    metricLabel: "Leads / Month",
  },
  {
    industry: "Estate Agency",
    location: "Northwest England",
    result: "Response time cut from 6 hours to under 2 minutes",
    quote: "Property enquiries don't wait. A buyer who doesn't get a response in the first hour will move on to the next listing. Since Pulse went live, every enquiry is handled instantly — and we get a structured lead with everything we need before we even pick up the phone.",
    metric: "< 2min",
    metricLabel: "Response Time",
  },
  {
    industry: "Insurance Broker",
    location: "UK",
    result: "Zero missed enquiries since going live",
    quote: "Weekend enquiries used to disappear into a void. Now Pulse handles them the moment they arrive — asks the right questions, understands what cover they're looking for, and has a qualified summary in our inbox by Monday morning. It's transformed how we start the week.",
    metric: "0",
    metricLabel: "Missed Enquiries",
  },
  {
    industry: "Accountancy Practice",
    location: "Manchester",
    result: "Appointment bookings up 40% in 6 weeks",
    quote: "We were spending too much time on initial calls that went nowhere. Pulse now handles that first conversation — it understands what the prospect needs, filters out those who aren't a fit, and books discovery calls directly into our calendar. Our conversion rate has improved significantly.",
    metric: "+40%",
    metricLabel: "Bookings",
  },
];

// ─── Data & Security ──────────────────────────────────────────────────────────
function DataSecurity() {
  return (
    <section id="security" className="py-28" style={{ background: "#ffffff" }}>
      <div className="max-w-7xl mx-auto px-6 lg:px-10">
        <div className="mb-16 text-center">
          <span className="text-xs font-bold tracking-widest uppercase mb-3 block" style={{ color: "#0ea5e9" }}>
            Data & Security
          </span>
          <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 leading-tight" style={{ fontFamily: "'Playfair Display', serif" }}>
            Your Data is <span style={{ color: "#F5A623" }}>Safe With Us.</span>
          </h2>
          <p className="text-gray-500 mt-4 max-w-2xl mx-auto text-lg">
            We take data protection seriously. Here is exactly what we collect, how we protect it, and what rights you have.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
          {/* What We Collect */}
          <div className="p-8 border" style={{ borderColor: "#e0f2fe", borderTop: "3px solid #0ea5e9" }}>
            <h3 className="text-xl font-bold text-gray-900 mb-4" style={{ fontFamily: "'Playfair Display', serif" }}>What We Collect</h3>
            <p className="text-gray-500 text-sm mb-4">When a visitor interacts with Pulse on your website, we capture:</p>
            <ul className="flex flex-col gap-3 mb-6">
              {["Name, email, phone number, a short enquiry summary, and the full conversation transcript", "Date and time captured", "Browser language and display preferences"].map(item => (
                <li key={item} className="flex items-start gap-3 text-sm text-gray-700">
                  <CheckCircle size={16} className="flex-shrink-0 mt-0.5" style={{ color: "#0ea5e9" }} />
                  {item}
                </li>
              ))}
            </ul>
            <p className="text-xs text-gray-400 border-t pt-4" style={{ borderColor: "#e0f2fe" }}>
              We never store payment card details or visitor passwords.
            </p>
          </div>

          {/* How It's Protected */}
          <div className="p-8 border" style={{ borderColor: "#e0f2fe", borderTop: "3px solid #F5A623" }}>
            <h3 className="text-xl font-bold text-gray-900 mb-4" style={{ fontFamily: "'Playfair Display', serif" }}>How It's Protected</h3>
            <ul className="flex flex-col gap-3">
              {[
                "Encrypted in transit: HTTPS/SSL between visitors, our server, and lead emails",
                "Encrypted at rest: sensitive lead fields (name, email, phone) are encrypted in our database",
                "Restricted database access: a dedicated, limited-permission database user — not full admin",
                "Firewall-protected server: only essential ports are open; the database is not reachable from outside",
                "Hashed login credentials: passwords are scrambled, never stored as readable text",
                "Daily automated backups, with 14-day rolling retention",
                "24/7 automated monitoring, with alerts if anything goes down",
              ].map(item => (
                <li key={item} className="flex items-start gap-3 text-sm text-gray-700">
                  <Shield size={16} className="flex-shrink-0 mt-0.5" style={{ color: "#0ea5e9" }} />
                  {item}
                </li>
              ))}
            </ul>
          </div>

          {/* Infrastructure */}
          <div className="p-8 border" style={{ borderColor: "#e0f2fe", borderTop: "3px solid #0ea5e9" }}>
            <h3 className="text-xl font-bold text-gray-900 mb-4" style={{ fontFamily: "'Playfair Display', serif" }}>Infrastructure</h3>
            <ul className="flex flex-col gap-3">
              {[
                "Hosted on our own private servers — not a shared third-party chatbot platform",
                "AI powered by Claude, from Anthropic",
                "Data stored in PostgreSQL, an industry-standard database",
                "Load-tested to handle multiple simultaneous conversations reliably",
              ].map(item => (
                <li key={item} className="flex items-start gap-3 text-sm text-gray-700">
                  <CheckCircle size={16} className="flex-shrink-0 mt-0.5" style={{ color: "#0ea5e9" }} />
                  {item}
                </li>
              ))}
            </ul>
          </div>

          {/* Your Data, Your Control */}
          <div className="p-8 border" style={{ borderColor: "#e0f2fe", borderTop: "3px solid #F5A623" }}>
            <h3 className="text-xl font-bold text-gray-900 mb-4" style={{ fontFamily: "'Playfair Display', serif" }}>Your Data, Your Control</h3>
            <ul className="flex flex-col gap-3 mb-6">
              {[
                "Never shared between clients — each business's data is fully separated",
                "Deletion available on request at any time",
                "Data is never sold or used for third-party marketing",
              ].map(item => (
                <li key={item} className="flex items-start gap-3 text-sm text-gray-700">
                  <CheckCircle size={16} className="flex-shrink-0 mt-0.5" style={{ color: "#F5A623" }} />
                  {item}
                </li>
              ))}
            </ul>
            <div className="p-4 mt-2" style={{ background: "#f0f9ff" }}>
              <p className="text-sm font-semibold text-gray-800 mb-1">Insurance</p>
              <p className="text-sm text-gray-600">Elvora Strategies is backed by Professional Indemnity Insurance, Cyber & Data Insurance, and Legal Protection Insurance.</p>
            </div>
          </div>
        </div>

        <div className="p-6 border-l-4 max-w-3xl mx-auto" style={{ borderColor: "#0ea5e9", background: "#f0f9ff" }}>
          <p className="text-sm font-semibold text-gray-800 mb-1">GDPR Compliant</p>
          <p className="text-sm text-gray-600">Elvora Strategies is fully insured and GDPR-compliant. We support the right to erasure and data access requests. For any data-related enquiry, contact <a href="mailto:info@elvorastrategies.com" className="underline" style={{ color: "#0284c7" }}>info@elvorastrategies.com</a>.</p>
          <p className="text-xs text-gray-400 mt-3">Last updated: August 2026</p>
        </div>
      </div>
    </section>
  );
}

// ─── FAQ ──────────────────────────────────────────────────────────────────────
function FAQ() {
  return (
    <section className="py-28" style={{ background: "#ffffff" }}>
      <div className="max-w-4xl mx-auto px-6 lg:px-10">
        <div className="mb-16 text-center">
          <span className="text-xs font-bold tracking-widest uppercase mb-3 block" style={{ color: "#0ea5e9" }}>
            Questions?
          </span>
          <h2
            className="text-4xl lg:text-5xl font-bold text-gray-900 leading-tight mb-6"
            style={{ fontFamily: "'Playfair Display', serif" }}
          >
            We Believe in <span style={{ color: "#F5A623" }}>Pulse</span>
          </h2>
          <p className="text-gray-600 text-lg max-w-2xl mx-auto mb-10">
            Pulse handles everything — from the first conversation to the final handoff. If you have questions about how it works, how it integrates, or what it can do for your business, just ask Pulse directly.
          </p>
          <button
            onClick={openChatbot}
            className="font-semibold text-base px-8 py-3 transition-all duration-200 active:scale-95 hover:shadow-lg"
            style={{ background: "#F5A623", color: "#1a1a1a", borderRadius: "2px" }}
          >
            Ask Pulse Your Questions
          </button>
        </div>
      </div>
    </section>
  );
}

function Testimonials() {
  return (
    <section className="py-28" style={{ background: "#ffffff" }}>
      <div className="max-w-7xl mx-auto px-6 lg:px-10">
        <div className="mb-16">
          <span className="text-xs font-bold tracking-widest uppercase mb-3 block" style={{ color: "#0ea5e9" }}>
            Results That Speak
          </span>
          <h2
            className="text-4xl lg:text-5xl font-bold text-gray-900 leading-tight max-w-2xl"
            style={{ fontFamily: "'Playfair Display', serif" }}
          >
            Real Outcomes for{" "}
            <span style={{ color: "#F5A623" }}>Real Businesses</span>
          </h2>
          <p className="text-gray-500 mt-4 max-w-xl">
            Every result below is from a real deployment. No client names — just the outcomes that matter.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {TESTIMONIALS.map((t) => (
            <div
              key={t.industry}
              className="p-8 border border-gray-100 hover:border-amber-200 transition-colors"
              style={{ background: "#f8fbff" }}
            >
              {/* Industry badge */}
              <div className="flex items-center gap-3 mb-6">
                <span
                  className="text-xs font-bold tracking-widest uppercase px-3 py-1"
                  style={{ background: "#e0f2fe", color: "#0369a1" }}
                >
                  {t.industry}
                </span>
                <span className="text-xs text-gray-400">{t.location}</span>
              </div>

              {/* Metric */}
              <div className="mb-5" style={{ borderLeft: "3px solid #F5A623", paddingLeft: "1rem" }}>
                <div
                  className="text-4xl font-bold text-gray-900"
                  style={{ fontFamily: "'Playfair Display', serif" }}
                >
                  {t.metric}
                </div>
                <div className="text-xs font-bold tracking-widest uppercase text-gray-400 mt-1">
                  {t.metricLabel}
                </div>
              </div>

              {/* Quote */}
              <p className="text-gray-600 leading-relaxed text-sm italic mb-4">
                "{t.quote}"
              </p>

              {/* Result tag */}
              <p className="text-xs font-semibold" style={{ color: "#0ea5e9" }}>
                ✓ {t.result}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ─── Contact ──────────────────────────────────────────────────────────────────
function Contact() {
  return (
    <section id="contact" aria-hidden="true" style={{ background: "#ffffff", borderColor: "#fffafa", height: "8px" }}>
    </section>
  );
}

// ─── Footer ───────────────────────────────────────────────────────────────────
function Footer() {
  return (
    <footer className="py-14 border-t" style={{ background: "#ffffff", borderColor: "#f0e8d8" }}>
      <div className="max-w-7xl mx-auto px-6 lg:px-10">
        {/* Logo + Brand Name */}
        <div className="flex items-center gap-4 mb-10">
          <img src={LOGO_TRANSPARENT} alt="Elvora Strategies logo — AI chatbot and automation agency Manchester" className="h-12 w-auto" />
          <span
            className="font-black text-3xl text-gray-900 uppercase"
            style={{ fontFamily: "'DM Sans', sans-serif", letterSpacing: "0.15em" }}
          >
            Elvora Strategies
          </span>
        </div>

        {/* Links row */}
        <div className="flex items-center gap-4 mb-4 flex-nowrap">
          <a href="/privacy-policy" className="text-gray-500 hover:text-gray-800 text-sm transition-colors whitespace-nowrap">
            Privacy Policy
          </a>
          <span className="text-gray-300">·</span>
          <a href="/terms-of-use" className="text-gray-500 hover:text-gray-800 text-sm transition-colors whitespace-nowrap">
            Terms of Use
          </a>
          <span className="text-gray-300">·</span>
          <a href="/data-security" className="text-gray-500 hover:text-gray-800 text-sm transition-colors whitespace-nowrap">
            Data &amp; Security
          </a>
        </div>
        <address className="not-italic text-sm text-gray-500 leading-relaxed mb-5">
          <span className="font-semibold text-gray-700 block">ELVORASTRATEGIES LTD</span>
          First Floor, Swan Buildings, 20 Swan Street, Manchester, M4 5JW
        </address>
        {/* Icons row — below the links */}
        <div className="flex items-center gap-3 mb-8">
          <a
            href="mailto:info@elvorastrategies.com"
            className="w-8 h-8 flex items-center justify-center border border-gray-200 hover:border-amber-400 transition-colors flex-shrink-0"
            style={{ borderRadius: "8px" }}
            aria-label="Email Elvora Strategies"
          >
            <Mail size={14} className="text-gray-700" />
          </a>
          <a
            href="https://www.linkedin.com/company/elvora-strategies"
            target="_blank"
            rel="noopener noreferrer"
            className="w-8 h-8 flex items-center justify-center border border-gray-200 hover:border-blue-400 transition-colors flex-shrink-0"
            style={{ borderRadius: "8px" }}
            aria-label="LinkedIn"
          >
            <Linkedin size={14} className="text-gray-700" />
          </a>
          <a
            href="tel:+441615150022"
            className="w-8 h-8 flex items-center justify-center border border-gray-200 hover:border-sky-400 transition-colors flex-shrink-0"
            style={{ borderRadius: "8px" }}
            aria-label="Call Elvora Strategies"
          >
            <Phone size={14} className="text-gray-700" />
          </a>
          <a
            href="https://wa.me/447930234660"
            target="_blank"
            rel="noopener noreferrer"
            className="w-8 h-8 flex items-center justify-center border border-gray-200 hover:border-green-400 transition-colors flex-shrink-0"
            style={{ borderRadius: "8px" }}
            aria-label="WhatsApp"
          >
            <MessageSquare size={14} className="text-gray-700" />
          </a>
        </div>

        {/* Copyright — very last */}
        <p className="text-gray-400 text-sm">
          © {new Date().getFullYear()} Elvora Strategies. All rights reserved.
        </p>
      </div>
    </footer>
  );
}

// ─── Page ─────────────────────────────────────────────────────────────────────
export default function Home() {
  return (
    <div className="min-h-screen">
      <Navbar />
      <SignalBar />
      <Hero />
      <Ticker />
      <Services />
      <Process />
      <Industries />
      <About />
      <FAQ />
      <Pricing />
      <WhiteLabelling />
      <Contact />
      <Footer />
    </div>
  );
}
